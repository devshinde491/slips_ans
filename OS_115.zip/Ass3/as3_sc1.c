#include <stdio.h>

#define P 5 // Number of processes
#define R 4 // Number of resource types

// Function to calculate need matrix
void calculateNeed(int need[P][R], int max[P][R], int allocation[P][R]) {
    for (int i = 0; i < P; i++) {
        for (int j = 0; j < R; j++) {
            need[i][j] = max[i][j] - allocation[i][j];
        }
    }
}

// Function to check if the system is in a safe state
int isSafe(int processes[], int avail[], int max[][R], int allocation[][R]) {
    int need[P][R];
    calculateNeed(need, max, allocation);

    int finish[P] = {0}, safeSeq[P], work[R];
    for (int i = 0; i < R; i++)
        work[i] = avail[i];

    int count = 0;
    while (count < P) {
        int found = 0;
        for (int p = 0; p < P; p++) {
            if (finish[p] == 0) {
                int j;
                for (j = 0; j < R; j++)
                    if (need[p][j] > work[j])
                        break;

                if (j == R) {
                    for (int k = 0; k < R; k++)
                        work[k] += allocation[p][k];

                    safeSeq[count++] = p;
                    finish[p] = 1;
                    found = 1;
                }
            }
        }

        if (found == 0) {
            printf("The system is not in a safe state.\n");
            return 0;
        }
    }

    printf("System is in a safe state.\nSafe sequence is: ");
    for (int i = 0; i < P; i++)
        printf("P%d ", safeSeq[i]);
    printf("\n");
    return 1;
}

// Function to request resources for a process
void requestResources(int avail[], int allocation[P][R], int need[P][R], int process, int request[R]) {
    int grant = 1;

    // Check if the request can be granted
    for (int i = 0; i < R; i++) {
        if (request[i] > need[process][i]) {
            grant = 0;
            printf("Error: Process has exceeded its maximum claim.\n");
            return;
        }
        if (request[i] > avail[i]) {
            grant = 0;
            printf("Request cannot be granted as resources are not available.\n");
            return;
        }
    }

    if (grant) {
        // Pretend to allocate requested resources
        for (int i = 0; i < R; i++) {
            avail[i] -= request[i];
            allocation[process][i] += request[i];
            need[process][i] -= request[i];
        }

        // Check if the system is in a safe state
        if (isSafe((int[]){0, 1, 2, 3, 4}, avail, need, allocation)) {
            printf("Request can be granted.\n");
        } else {
            printf("Request cannot be granted as it leaves the system in an unsafe state.\n");
            // Rollback the allocation
            for (int i = 0; i < R; i++) {
                avail[i] += request[i];
                allocation[process][i] -= request[i];
                need[process][i] += request[i];
            }
        }
    }
}

int main() {
    // Processes P0, P1, P2, P3, P4
    int processes[] = {0, 1, 2, 3, 4};

    // Available instances of resources A, B, C, D
    int avail[R] = {1, 5, 2, 0};

    // Maximum resources that can be allocated to processes
    int max[P][R] = {
        {0, 0, 1, 2},
        {1, 7, 5, 0},
        {2, 3, 5, 6},
        {0, 6, 5, 2},
        {0, 6, 5, 6}
    };

    // Resources currently allocated to processes
    int allocation[P][R] = {
        {0, 0, 1, 2},
        {1, 0, 0, 0},
        {1, 3, 5, 4},
        {0, 6, 3, 2},
        {0, 0, 1, 4}
    };

    // Calculate the Need matrix
    int need[P][R];
    calculateNeed(need, max, allocation);

    // Display the Need matrix
    printf("Need matrix:\n");
    for (int i = 0; i < P; i++) {
        for (int j = 0; j < R; j++)
            printf("%d ", need[i][j]);
        printf("\n");
    }

    // Check if the system is in a safe state
    isSafe(processes, avail, max, allocation);

    // Resource request from P1: {0, 4, 2, 0}
    int request[R] = {0, 4, 2, 0};
    printf("Request from P1 for resources: {0, 4, 2, 0}\n");
    requestResources(avail, allocation, need, 1, request);

    return 0;
}
