#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define MAX_PROCESSES 10

typedef struct {
    int id, arrival_time, burst_time, start_time, finish_time, waiting_time, turnaround_time;
} Process;

int find_shortest_job(Process p[], int n, int current_time) {
    int min_index = -1;
    int min_burst_time = 10000; 

    for (int i = 0; i < n; i++) {
        if (p[i].arrival_time <= current_time && p[i].finish_time == 0 && p[i].burst_time < min_burst_time) {
            min_burst_time = p[i].burst_time;
            min_index = i;
        }
    }
    return min_index;
}

void sjf_scheduling(Process p[], int n) {
    int current_time = 0;
    int completed = 0;

    while (completed < n) {
        int index = find_shortest_job(p, n, current_time);
        if (index == -1) {
            current_time++; 
            continue;
        }
        p[index].start_time = current_time;
        p[index].finish_time = current_time + p[index].burst_time;
        p[index].waiting_time = p[index].start_time - p[index].arrival_time;
        p[index].turnaround_time = p[index].finish_time - p[index].arrival_time;
        current_time = p[index].finish_time;
        completed++;
    }
}

void print_results(Process p[], int n) {
    float total_waiting = 0, total_turnaround = 0;
    printf("\nGantt Chart:\n| ");
    for (int i = 0; i < n; i++) {
        printf("P%d | ", p[i].id);
    }
    printf("\n0 ");
    for (int i = 0; i < n; i++) {
        printf(" %d ", p[i].finish_time);
    }
    printf("\n");

    printf("\nProcess\tArrival\tBurst\tStart\tFinish\tWaiting\tTurnaround\n");
    for (int i = 0; i < n; i++) {
        printf("P%d\t %d\t %d\t %d\t %d\t %d\t %d\n", p[i].id, p[i].arrival_time, p[i].burst_time, p[i].start_time, p[i].finish_time, p[i].waiting_time, p[i].turnaround_time);
        total_waiting += p[i].waiting_time;
        total_turnaround += p[i].turnaround_time;
    }
    printf("\nAverage Waiting Time: %.2f\n", total_waiting / n);
    printf("Average Turnaround Time: %.2f\n", total_turnaround / n);
}

int main() {
    int n;

    printf("Enter the number of processes (max %d): ", MAX_PROCESSES);
    scanf("%d", &n);
    if (n > MAX_PROCESSES) {
        printf("Number of processes exceeds the limit.\n");
        return 1;
    }
    srand(time(NULL)); 

    Process p[n];
    for (int i = 0; i < n; i++) {
        p[i].id = i;
        printf("Enter arrival time for process P%d: ", i);
        scanf("%d", &p[i].arrival_time);
        p[i].burst_time = rand() % 10 + 1;
        p[i].finish_time = 0; 
        printf("Burst time for process P%d (generated randomly): %d\n", i, p[i].burst_time);
    }
    sjf_scheduling(p, n);
    print_results(p, n);
    return 0;
}