#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    int n;
    printf("Enter number of processes: ");
    scanf("%d", &n);
    
    int arrival[n], burst[n], priority[n];
    int waiting[n], turnaround[n];
    
    // Seed random number generator
    srand(time(NULL));

    // Input arrival times, burst times, and priorities
    for (int i = 0; i < n; i++) {
        printf("Enter arrival time for Process %d: ", i + 1);
        scanf("%d", &arrival[i]);
        printf("Enter initial CPU burst time for Process %d: ", i + 1);
        scanf("%d", &burst[i]);
        printf("Enter priority for Process %d (lower value = higher priority): ", i + 1);
        scanf("%d", &priority[i]);
    }

    // Variables to keep track of times
    int current_time = 0, completed = 0;
    int total_waiting = 0, total_turnaround = 0;

    printf("Gantt Chart:\n");

    while (completed < n) {
        int idx = -1; // Index of the next process to execute

        // Find the next process to execute based on arrival time and priority
        for (int i = 0; i < n; i++) {
            if (arrival[i] <= current_time && (idx == -1 || priority[i] < priority[idx])) {
                idx = i;
            }
        }

        // If a process is found
        if (idx != -1) {
            printf("P%d ", idx + 1); // Print process number
            current_time += burst[idx] + 2; // Execute process and add I/O wait time
            turnaround[idx] = current_time - arrival[idx];
            waiting[idx] = turnaround[idx] - burst[idx];

            total_waiting += waiting[idx];
            total_turnaround += turnaround[idx];
            completed++;
            
            // Generate next CPU burst time randomly (between 1 to 10)
            burst[idx] = rand() % 10 + 1; 
        } else {
            // If no process is ready, increment time
            current_time++;
        }
    }
    
    printf("\n");

    // Print waiting and turnaround times for each process
    for (int i = 0; i < n; i++) {
        printf("Process %d | Waiting: %d | Turnaround: %d\n", i + 1, waiting[i], turnaround[i]);
    }

    // Print average waiting and turnaround times
    printf("Avg Waiting Time: %.2f\n", (float)total_waiting / n);
    printf("Avg Turnaround Time: %.2f\n", (float)total_turnaround / n);

    return 0;
}
