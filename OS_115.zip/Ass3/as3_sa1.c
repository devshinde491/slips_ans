#include <stdio.h>

int main() {
    int P, M, min_resources;

    printf("Enter the number of processes (P): ");
    scanf("%d", &P);

    printf("Enter the maximum number of resources a process can request (M): ");
    scanf("%d", &M);

    // Formula to calculate the minimum resources required to avoid deadlock
    min_resources = P * (M - 1) + 1;

    printf("The minimum number of resources needed to avoid deadlock: %d\n", min_resources);

    return 0;
}
