#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>

int main(){
    pid_t pid;
    pid = fork();

    if(pid < 0){
        perror("Fork Failed");
        return 1;
    } else if(pid == 0){
        printf("Child process before nice() cell. PID: %d, Prioprity: %d\n", getpid(), nice(0));
        nice(5);
        printf("Child process after nice() cell. PID: %d, Prioprity: %d\n", getpid(), nice(0));
    } else {
        printf("Parent process . PID: %d\n", getpid());
    }
    return 0;
}