#include <stdio.h>

struct process {
    int id;               // Process ID
    int arrival_time;      // Arrival time
    int burst_time;        // CPU burst time
    int priority;          // Priority (lower value means higher priority)
    int waiting_time;      // Waiting time
    int turnaround_time;   // Turnaround time
    int start_time;        // Start time
    int finish_time;       // Finish time
};

void priorityScheduling(struct process p[], int n) {
    int time = 0;
    float total_waiting_time = 0, total_turnaround_time = 0;

    // Sorting by priority (lower priority number = higher priority)
    for (int i = 0; i < n - 1; i++) {
        for (int j = i + 1; j < n; j++) {
            if (p[j].priority < p[i].priority) {
                struct process temp = p[i];
                p[i] = p[j];
                p[j] = temp;
            }
        }
    }

    // Gantt Chart simulation and calculating waiting/turnaround time
    printf("\nGantt Chart:\n");
    for (int i = 0; i < n; i++) {
        if (time < p[i].arrival_time) {
            time = p[i].arrival_time; // Adjust time for arrival
        }
        p[i].start_time = time;  // Set start time
        p[i].finish_time = time + p[i].burst_time; // Set finish time

        printf("| P%d (%d-%d) ", p[i].id, p[i].start_time, p[i].finish_time);

        // Calculate waiting and turnaround times
        p[i].waiting_time = p[i].start_time - p[i].arrival_time;
        p[i].turnaround_time = p[i].finish_time - p[i].arrival_time;
        
        total_waiting_time += p[i].waiting_time;
        total_turnaround_time += p[i].turnaround_time;

        time = p[i].finish_time;
    }
    printf("|\n");

    // Display process information
    printf("\nProcess\tArrival\tBurst\tPriority\tStart\tFinish\tWaiting\tTurnaround\n");
    for (int i = 0; i < n; i++) {
        printf("P%d\t%d\t%d\t%d\t\t%d\t%d\t%d\t%d\n", p[i].id, p[i].arrival_time, p[i].burst_time,
               p[i].priority, p[i].start_time, p[i].finish_time, p[i].waiting_time, p[i].turnaround_time);
    }

    // Display average waiting and turnaround times
    printf("\nAverage Waiting Time: %.2f\n", total_waiting_time / n);
    printf("Average Turnaround Time: %.2f\n", total_turnaround_time / n);
}

int main() {
    int n;

    // Input the number of processes
    printf("Enter the number of processes: ");
    scanf("%d", &n);

    struct process p[n];

    // Input process details
    for (int i = 0; i < n; i++) {
        p[i].id = i + 1;
        printf("Enter arrival time, burst time and priority for Process P%d: ", p[i].id);
        scanf("%d %d %d", &p[i].arrival_time, &p[i].burst_time, &p[i].priority);
    }

    // Perform Non-preemptive Priority Scheduling
    priorityScheduling(p, n);

    return 0;
}
