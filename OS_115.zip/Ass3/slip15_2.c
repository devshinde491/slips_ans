#include <stdio.h>

int find_least_recently_used(int time[], int n) {
    int min_idx = 0;
    for (int i = 1; i < n; i++)
        if (time[i] < time[min_idx]) min_idx = i;
    return min_idx;
}

int main() {
    int n;
    printf("Enter number of memory frames: ");
    scanf("%d", &n);

    int frames[n], time[n], page_faults = 0;
    int pages[] = {7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2};
    int total_pages = sizeof(pages) / sizeof(pages[0]);

    // Initialize frames and time
    for (int i = 0; i < n; i++) {
        frames[i] = -1;
        time[i] = 0;
    }

    // Process each page
    for (int count = 0, i = 0; i < total_pages; i++) {
        int found = 0;

        // Check if the page is already in the frames
        for (int j = 0; j < n; j++) {
            if (frames[j] == pages[i]) {
                found = 1;
                time[j] = count++; // Update the time for LRU
                break;
            }
        }

        // If page not found, replace the least recently used frame
        if (!found) {
            int lru_idx = find_least_recently_used(time, n);
            frames[lru_idx] = pages[i]; // Replace LRU frame
            time[lru_idx] = count++; // Update the time for this frame
            page_faults++; // Increment page fault count
        }

        // Print current frame state and hit/fault
        printf("Frames: ");
        for (int j = 0; j < n; j++)
            printf("%d ", frames[j] == -1 ? -1 : frames[j]);
        
        if (found) {
            printf("H\n"); // Print 'H' if it's a hit
        } else {
            printf("F\n"); // Print 'F' if it's a fault
        }
    }

    // Print total page faults
    printf("Total Page Faults: %d\n", page_faults);
    return 0;
}
