#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int id;
    int arrival_time;
    int burst_time;
    int waiting_time;
    int turnaround_time;
} Process;

int main() {
    int n;
    printf("Enter number of processes: ");
    scanf("%d", &n);
    
    Process p[n];
    
    // Input arrival times and generate burst times
    for (int i = 0; i < n; i++) {
        p[i].id = i + 1;
        printf("Enter arrival time for Process %d: ", p[i].id);
        scanf("%d", &p[i].arrival_time);
        p[i].burst_time = rand() % 10 + 1; // Random burst time between 1 and 10
    }

    // Initialize current time and total times
    int current_time = 0;
    int total_waiting = 0;
    int total_turnaround = 0;
    int completed = 0;

    // Process scheduling
    while (completed < n) {
        int min_burst = 9999; // Initialize min burst time
        int idx = -1; // Index of the process to execute next

        // Find the process with the shortest burst time that has arrived
        for (int i = 0; i < n; i++) {
            if (p[i].arrival_time <= current_time && p[i].burst_time < min_burst) {
                min_burst = p[i].burst_time;
                idx = i;
            }
        }

        // If a process is found
        if (idx != -1) {
            current_time += p[idx].burst_time + 2; // Add I/O wait time
            p[idx].turnaround_time = current_time - p[idx].arrival_time;
            p[idx].waiting_time = p[idx].turnaround_time - p[idx].burst_time;

            total_waiting += p[idx].waiting_time;
            total_turnaround += p[idx].turnaround_time;
            completed++;

            // Print waiting and turnaround times for the current process
            printf("Process %d | Waiting: %d | Turnaround: %d\n", p[idx].id, p[idx].waiting_time, p[idx].turnaround_time);
        } else {
            // If no process is available, increment current time
            current_time++;
        }
    }

    // Print average waiting and turnaround times
    printf("Avg Waiting Time: %.2f\n", (float)total_waiting / n);
    printf("Avg Turnaround Time: %.2f\n", (float)total_turnaround / n);

    return 0;
}
