#include<stdio.h>
int find_optimal(int frames[], int pages[], int pos, int total, int n){
    for(int i=0; i<n; i++){
        int j;
        for(j=pos; j<total; j++){
            if(frames[i] == pages[j])
                break;
        }
        if(j == total){
            return i;
        }
    }
    return 0;
}

int main(){
    int n;
    printf("Enter the number of memory frames: ");
    scanf("%d", &n);

    int frames[n], pages[]={12, 15, 12, 18, 6, 8, 11, 12, 19, 12, 6, 8, 12, 15, 19, 8};
    int total_pages = sizeof(pages)/sizeof(pages[0]);
    int page_foults = 0;

    for(int i=0; i<n; i++){
        frames[i] = -1;
    }

    for(int i=0; i<total_pages; i++){
        int found = 0;
        for(int j=0; j<n; j++){
            if(frames[j] == pages[i]){
                found = 1;
                break;
            }
        }
        printf("Frames: ");
        for(int j=0; j< n; j++){
            printf("%d ", frames[j]);
        }

        if(found){
            printf("H ");
        }
        else{
            printf("F ");
            int idx = find_optimal(frames, pages, i+1, total_pages, n);
            frames[idx] = pages[i];
            page_foults++;
        }

        printf("\n");
    }
    printf("Total Page Faults: %d\n", page_foults);
    return 0;
}