#include <stdio.h>

#define MAX 10

int allocation[MAX][MAX], max[MAX][MAX], need[MAX][MAX], available[MAX];
int p, r;  // number of processes and resources

// Function to accept input
void input_data() {
    printf("Enter Allocation Matrix:\n");
    for (int i = 0; i < p; i++)
        for (int j = 0; j < r; j++)
            scanf("%d", &allocation[i][j]);

    printf("Enter Max Matrix:\n");
    for (int i = 0; i < p; i++)
        for (int j = 0; j < r; j++)
            scanf("%d", &max[i][j]);

    printf("Enter Available Resources:\n");
    for (int i = 0; i < r; i++)
        scanf("%d", &available[i]);
}

// Function to calculate the Need matrix
void calculate_need() {
    for (int i = 0; i < p; i++)
        for (int j = 0; j < r; j++)
            need[i][j] = max[i][j] - allocation[i][j];
}

// Function to display data in tabular format
void display() {
    printf("\nProcess | Allocation | Max | Need | Available\n");
    for (int i = 0; i < p; i++) {
        printf("P%d      | ", i + 1);
        for (int j = 0; j < r; j++) printf("%d ", allocation[i][j]);
        printf("| ");
        for (int j = 0; j < r; j++) printf("%d ", max[i][j]);
        printf("| ");
        for (int j = 0; j < r; j++) printf("%d ", need[i][j]);
        if (i == 0) {
            printf("| ");
            for (int j = 0; j < r; j++) printf("%d ", available[j]);
        }
        printf("\n");
    }
}

int main() {
    printf("Enter number of processes and resources: ");
    scanf("%d %d", &p, &r);

    input_data();
    calculate_need();
    display();

    return 0;
}
