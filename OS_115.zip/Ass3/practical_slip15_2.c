#include<stdio.h>
int find_least_recently_used(int time[], int n){
    int min_idx = 0;
    for(int i=0; i<n; i++)
        if(time[i] < time[min_idx]) min_idx = i;
    return min_idx;
}

int main(){
    int n;
    printf("Enter the number of memory frames: ");
    scanf("%d", &n);

    int frames[n], time[n], page_foults = 0, count = 0;
    int pages[] = {7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2};
    int total_pages = sizeof(pages) / sizeof(pages[0]);

    for(int i=0; i<n; i++){
        frames[i] = -1;
        time[i] = 0; 
    }

    for(int i=0; i< total_pages; i++){
        int found = 0;
        for(int j=0; j<n; j++){
            if(frames[j] == pages[i]){
                found = 1;
                time[j] = count++;
                break;
            }
        }

        if(!found){
            int lru_idx= find_least_recently_used(time, n);
            frames[lru_idx] =pages[i];
            time[lru_idx] = count++;
            page_foults++;
        }

        printf("Frames: ");
        for(int j=0; j<n; j++){
            printf("%d ", frames[j] == -1 ? -1: frames[j]);
        }
        if(found){
            printf("H\n");
        } else{
            printf("F\n");
        }
    }

    printf("Total page foults: %d\n", page_foults );
    return 0;
}