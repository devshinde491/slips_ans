#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    int n, quantum;
    printf("Enter number of processes: ");
    scanf("%d", &n);
    
    int arrival[n], burst[n], remaining[n], waiting[n], turnaround[n];
    
    // Seed random number generator
    srand(time(NULL));

    // Input arrival times and burst times
    for (int i = 0; i < n; i++) {
        printf("Enter arrival time for Process %d: ", i + 1);
        scanf("%d", &arrival[i]);
        printf("Enter initial CPU burst time for Process %d: ", i + 1);
        scanf("%d", &burst[i]);
        remaining[i] = burst[i]; // Initialize remaining burst time
    }

    printf("Enter time quantum: ");
    scanf("%d", &quantum);

    // Variables to keep track of times
    int current_time = 0, completed = 0;
    int total_waiting = 0, total_turnaround = 0;

    printf("Gantt Chart:\n");

    // Continue until all processes are completed
    while (completed < n) {
        int process_executed = 0; // Flag to check if any process executed in the current round
        
        for (int i = 0; i < n; i++) {
            // Check if the process has arrived and has remaining time
            if (arrival[i] <= current_time && remaining[i] > 0) {
                process_executed = 1; // Process executed in this round
                
                // Determine the actual time to execute (either quantum or remaining time)
                int time_to_execute = (remaining[i] < quantum) ? remaining[i] : quantum;

                // Print the process in the Gantt chart
                printf("P%d ", i + 1);
                current_time += time_to_execute; // Update current time
                remaining[i] -= time_to_execute; // Reduce remaining burst time

                // If the process is completed
                if (remaining[i] == 0) {
                    completed++;
                    turnaround[i] = current_time - arrival[i]; // Calculate turnaround time
                    waiting[i] = turnaround[i] - burst[i]; // Calculate waiting time
                    total_waiting += waiting[i];
                    total_turnaround += turnaround[i];
                }

                // Generate next CPU burst time randomly (between 1 to 10)
                if (remaining[i] > 0) {
                    remaining[i] += rand() % 10 + 1; // Randomly increase remaining burst time for next turn
                }

                current_time += 2; // Add I/O waiting time after each process execution
            }
        }
        
        // If no process was executed, move the current time forward
        if (!process_executed) {
            current_time++;
        }
    }

    printf("\n");

    // Print waiting and turnaround times for each process
    for (int i = 0; i < n; i++) {
        printf("Process %d | Waiting: %d | Turnaround: %d\n", i + 1, waiting[i], turnaround[i]);
    }

    // Print average waiting and turnaround times
    printf("Avg Waiting Time: %.2f\n", (float)total_waiting / n);
    printf("Avg Turnaround Time: %.2f\n", (float)total_turnaround / n);

    return 0;
}
