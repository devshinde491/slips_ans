#include<stdio.h>
int main(){
    int n;
    printf("Enter the number of memory frames: ");
    scanf("%d", &n);

    int frames[n], pages[]={3, 4, 5, 6, 3, 4, 7, 3, 4, 5, 6, 7, 2, 4, 6};
    int total_pages = sizeof(pages)/ sizeof(pages[0]);
    int page_foults = 0, next_replace = 0;

    for(int i = 0; i<n; i++){
        frames[i] = -1;
    } 

    for(int i=0; i<total_pages; i++){
        int found = 0;

        for(int j=0; j<n; j++){
            if(frames[j] == pages[i]){
                found = 1;
                break;
            }
        }

        printf("Frames: ");
        for(int j=0; j<n; j++){
            printf("%d ", frames[j]);
        }

        if(found){
            printf("H ");
        }
        else{
            frames[next_replace] = pages[i];
            next_replace = (next_replace + 1) % n;
            page_foults++;
            printf("F ");
        }
        printf("\n");
    }

    printf("Total Page foults: %d\n", page_foults);
    return 0;
}