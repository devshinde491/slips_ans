#include<stdio.h>
#include<unistd.h>


int main(){
    pid_t pid = fork();

    if(pid < 0){
        perror("Fork failed");
        return 1;
    }

    if(pid == 0){
        printf("Child proccess running with default priority. \n");
        nice(-5);
        printf("child process priority increase using nice.\n");
        sleep(2);
    }else{
        wait(NULL);
        printf("Child proccess finished, parent process continues. \n");
    }

    return 0;
}