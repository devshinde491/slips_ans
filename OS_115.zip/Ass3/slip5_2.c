#include <stdio.h>
#include <stdlib.h>
#include <time.h>

struct process {
    int id;
    int arrival_time;
    int burst_time;
    int remaining_time;
    int start_time;      
    int waiting_time;
    int turnaround_time;
    int finish_time;
};

void roundRobin(struct process p[], int n, int time_quantum) {
    int time = 0, completed = 0;
    float total_waiting_time = 0, total_turnaround_time = 0;

    while (completed < n) {
        for (int i = 0; i < n; i++) {
            if (p[i].remaining_time > 0 && p[i].arrival_time <= time) {
                if (p[i].start_time == -1) {
                    // Set start time only the first time the process starts executing
                    p[i].start_time = time;
                }

                int exec_time = (p[i].remaining_time > time_quantum) ? time_quantum : p[i].remaining_time;
                time += exec_time;
                p[i].remaining_time -= exec_time;

                if (p[i].remaining_time == 0) {
                    p[i].finish_time = time;
                    p[i].turnaround_time = p[i].finish_time - p[i].arrival_time;
                    p[i].waiting_time = p[i].turnaround_time - p[i].burst_time;
                    completed++;
                    total_waiting_time += p[i].waiting_time;
                    total_turnaround_time += p[i].turnaround_time;
                }
            }
        }
    }

    // Display Process Information
    printf("\nProcess\tArrival Time\tBurst Time\tStart Time\tFinish Time\tWaiting Time\tTurnaround Time\n");
    for (int i = 0; i < n; i++) {
        printf("P%d\t%d\t\t%d\t\t%d\t\t%d\t\t%d\t\t%d\n", p[i].id, p[i].arrival_time, p[i].burst_time, p[i].start_time, p[i].finish_time, p[i].waiting_time, p[i].turnaround_time);
    }

    // Display Average Waiting Time and Turnaround Time
    printf("\nAverage Waiting Time: %.2f\n", total_waiting_time / n);
    printf("Average Turnaround Time: %.2f\n", total_turnaround_time / n);
}

int main() {
    int n, time_quantum;

    srand(time(0));

    printf("Enter the number of processes: ");
    scanf("%d", &n);

    struct process p[n];

    for (int i = 0; i < n; i++) {
        p[i].id = i + 1;
        printf("Enter arrival time for Process P%d: ", p[i].id);
        scanf("%d", &p[i].arrival_time);
        p[i].burst_time = rand() % 10 + 1; // Random burst time between 1 and 10
        p[i].remaining_time = p[i].burst_time;
        p[i].start_time = -1;  // Initialize start time as -1 (unset)
        printf("Random Burst Time for Process P%d: %d\n", p[i].id, p[i].burst_time);
    }

    printf("Enter the time quantum: ");
    scanf("%d", &time_quantum);

    roundRobin(p, n, time_quantum);

    return 0;
}
