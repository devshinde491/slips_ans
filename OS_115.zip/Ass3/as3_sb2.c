#include <stdio.h>

int main() {
    int allocation[5][3] = { {0, 1, 0}, {2, 0, 0}, {3, 0, 3}, {2, 1, 1}, {0, 0, 2} };
    int request[5][3] = { {0, 0, 0}, {2, 0, 2}, {0, 0, 1}, {1, 0, 0}, {0, 0, 2} };
    int available[3], total_resources[3] = {7, 2, 6};
    
    int allocated_sum[3] = {0, 0, 0};
    
    // Calculate total allocated resources
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 3; j++) {
            allocated_sum[j] += allocation[i][j];
        }
    }
    
    // Calculate available resources
    for (int i = 0; i < 3; i++) {
        available[i] = total_resources[i] - allocated_sum[i];
    }
    
    // Display Available array
    printf("Available resources: A = %d, B = %d, C = %d\n", available[0], available[1], available[2]);
    
    // Check for deadlock using Banker's Algorithm (simplified)
    int finish[5] = {0, 0, 0, 0, 0}; // Track finished processes
    int deadlock = 0;
    
    // Simulate the safe sequence
    for (int k = 0; k < 5; k++) {
        for (int i = 0; i < 5; i++) {
            if (!finish[i]) {
                int can_finish = 1;
                for (int j = 0; j < 3; j++) {
                    if (request[i][j] > available[j]) {
                        can_finish = 0;
                        break;
                    }
                }
                if (can_finish) {
                    for (int j = 0; j < 3; j++) {
                        available[j] += allocation[i][j];
                    }
                    finish[i] = 1;
                }
            }
        }
    }
    
    // Check if all processes finished
    for (int i = 0; i < 5; i++) {
        if (!finish[i]) {
            deadlock = 1;
            break;
        }
    }
    
    // Output result
    if (deadlock) {
        printf("Deadlock detected.\n");
    } else {
        printf("No deadlock. All processes can finish.\n");
    }

    return 0;
}
