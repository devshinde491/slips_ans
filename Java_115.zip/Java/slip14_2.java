interface Operation { 
	void area();
	void volume();
	double PI = 3.14;
}
class Circle implements Operation{
	double radius, height;
	Circle(double radius, double height){
		this.radius = radius;
	}
	
	public void area(){
		System.out.println("Area of Cylinder: " + (2 * PI * radius * (radius + height) ));
	}
	
	public void volume(){
		double result = PI * radius * (radius + height);
		System.out.println("Cylinder of Volume: " + result);
	}
}
public class slip14_2{
	public static void main(String []args){
		Circle c = new Circle(5.0, 2.0);
		c.area();
		c.volume();
	}
}		
