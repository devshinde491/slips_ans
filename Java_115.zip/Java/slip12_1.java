import series.SquareSeries;
import java.util.*;

public class slip12_1{
	public static void main(String []args){
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the number: ");
		int n = input.nextInt();
		
		SquareSeries s = new SquareSeries();
		s.print_series(n);
	}
}	
