import java.util.*;

class Product {
    String name;
    double price;
    
    public Product(String n, double p) {
        name = n;
        price = p;
    }
}
public class slip4_2 {
    public static void main(String args[]) {
        Scanner input = new Scanner(System.in);
        Product products[] = new Product[5];

        for (int i = 0; i < 5; i++) {
            System.out.println("Enter product name: ");
            String name = input.nextLine();

            System.out.println("Enter product price: ");
            double price = input.nextDouble();

            input.nextLine(); // Consume newline character
            products[i] = new Product(name, price);
        }
        
        Product minPriceProduct = products[0];
        for (int i = 1; i < products.length; i++) {
            if (products[i].price < minPriceProduct.price) {
                minPriceProduct = products[i];
            }
        }
        System.out.println("Products with the minimum price: " + minPriceProduct.name);
    }
}
