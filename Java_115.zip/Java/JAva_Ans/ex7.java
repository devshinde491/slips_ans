import java.io.*;
import java.util.*;
class ex7{

	public static void main(String args[]){
                                 Scanner scan=new Scanner(System.in);
                              	System.out.println("enter he size");
                              	int n=scan.nextInt();
                              	int num[]=new int[n];
                              	for(int i=0;i<n;i++){
                                  System.out.println("enter he numebr");
                              	num[i]=scan.nextInt();
                              	}

				int sum=num[0];
                              	for(int i=0;i<n;i++){
        			 if(num[i]>sum){
        			   sum=num[i];
        			}                     	
                              	}
                              	 System.out.println("max="+sum);

}
}
