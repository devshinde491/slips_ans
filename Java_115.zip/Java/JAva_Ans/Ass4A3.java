import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class Ass4A3
{
private static JTextArea textArea;
private static JLabel WordLabel;
private static JLabel CharLabel;
public static void main(String[]args){
JFrame frame=new JFrame("word & character count");
frame.setSize(400,300);
frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
JPanel panel=new JPanel();
panel.setLayout(null);
frame.add(panel);
WordLabel=new JLabel("words:0");
WordLabel.setBounds(50,20,120,25);
panel.add(WordLabel);
CharLabel=new JLabel("characters:0");
CharLabel.setBounds(200,20,150,25);
panel.add(CharLabel);
textArea=new JTextArea();
JScrollPane ScrollPane=new JScrollPane(textArea);
ScrollPane.setBounds(50,50,300,100);
ScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
ScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
panel.add(ScrollPane);
JButton countButton = new JButton ("count words");
countButton.setBounds(140,170,120,30);
panel.add(countButton);
countButton.addActionListener(new ActionListener()
{
public void actionPerformed(ActionEvent e)
			{
				String text=textArea.getText();
				String[]words=text.trim().split("\\s+");
				int WordCount=text.trim().isEmpty()?0:words.length;
				int CharCount=text.length();
				WordLabel.setText("words:"+WordCount);
				CharLabel.setText("characters:"+CharCount);
				}
				});
				frame.setVisible(true);
				}
				}
				
