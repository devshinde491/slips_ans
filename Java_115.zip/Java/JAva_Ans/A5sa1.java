import java.sql.*;
import java.io.*;
public class As5a1
{
public static void main(String args[])throws Exception
{
Class.forName("org.postgresql.Driver");
ResultSet rs=null;
try
{
Connection con=DriverManager.getConnection("jdbc:postgresql:test","postgres","");
if(con==null)
System.out.println("Connection failed");
else
{
System.out.println("Connection failed");
Statement smt = con.createStatement();
rs=smt.executeQuery("Select * from country");
while(rs.next())
{
System.out.println("cname="+rs.getInt(1));
System.out.println("continent="+rs.getString(2));
System.out.println("capital="+rs.getString(3));
System.out.println("region="+rs.getInt(4));
}
con.close();
}
}
catch(Exception e)
{
System.out.println(e);
}
}
}
