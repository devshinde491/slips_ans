import java.io.*;
import java.util.*;
class ex2
{
       

   
	public static void main(String args[]){
                              	Scanner scan=new Scanner(System.in);
                              	System.out.println("enter he size");
                              	                              	                              	 int n=scan.nextInt();
                              	int num[]=new int[n];
                              	for(int i=0;i<n;i++){
                              	                              	System.out.println("enter he numebr");
                              	                              	                              	 num[i]=scan.nextInt();
                              	}

int sum=0;
                              	for(int i=1;i<n;i++){
        			System.out.println("num["+i+"]="+num[i]);
        			sum=num[i];                      	
                        
                              	}
                              	 System.out.println("sum="+sum);
              	
	
	}


}
