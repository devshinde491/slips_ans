import java.util.*;
class circle
{
double r,a,p;
public void area()
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter radius:");
r=sc.nextFloat();
a=3.14*r*r;
System.out.println("area is:"+a);
}
public void peri()
{
Scanner sc=new Scanner(System.in);
System.out.println("enter radius:");
r=sc.nextFloat();
p=2*3.14*r;
System.out.println("peri is:"+p);
}
public static void main(String args[])
{
circle c=new circle();
c.area();
c.peri();
}
}
