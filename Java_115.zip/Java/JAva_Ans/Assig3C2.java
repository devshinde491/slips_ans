import java.util.Scanner;


class InvalidDateException extends Exception {
    public InvalidDateException(String message) {
        super(message);
    }
}

class Assig3C2 {
    private int day;
    private int month;
    private int year;


    public Assig3C2(int day, int month, int year) {
        this.day = day;
        this.month = month;
        this.year = year;
    }


    public static Assig3C2 acceptDate() throws InvalidDateException {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter day (dd): ");
        int day = scanner.nextInt();

        System.out.print("Enter month (mm): ");
        int month = scanner.nextInt();

        System.out.print("Enter year (yyyy): ");
        int year = scanner.nextInt();


        if (!isValidDate(day, month, year)) {
            throw new InvalidDateException("Invalid Date: The entered date is not valid.");
        }


        return new Assig3C2(day, month, year);
    }


    private static boolean isValidDate(int day, int month, int year) {

        if (year < 1 || month < 1 || month > 12 || day < 1) {
            return false;
        }


        int[] daysInMonth = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};


        if (isLeapYear(year)) {
            daysInMonth[1] = 29; 
        }


        if (day > daysInMonth[month - 1]) {
            return false;
        }

        return true;
    }


    private static boolean isLeapYear(int year) {
        if (year % 4 == 0) {
            if (year % 100 == 0) {
                return year % 400 == 0;
            } else {
                return true;
            }
        }
        return false;
    }


    public void display() {
        System.out.printf("Date: %02d-%02d-%04d\n", day, month, year);
    }

    public static void main(String[] args) {
        try {
            Assig3C2 date=Assig3C2.acceptDate();
            date.display();
        } catch (InvalidDateException e) {
            System.out.println(e.getMessage());
        }
    }
}
