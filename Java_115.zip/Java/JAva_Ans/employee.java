import java.util.*;
class employee
{
public static void main(String args[]) throws Exception
{
Scanner Sc=new Scanner(System.in);
System.out.println("enter basic salary");
double Salary=Sc.nextDouble();
double HRA=0.15*Salary;
double DA=0.10*Salary;
double TA=0.12*Salary;
double NS=HRA+DA+TA;
System.out.println("net salary is:"+NS);
if(NS>100000)
{
System.out.println("associative professor");
}
else
if(NS>50000)
{
System.out.println("assitant professor");
}
else
if(NS>30000)
{
System.out.println("professor");
}
else 
{
System.out.println("non teaching staff");
}
}
}
