import java.io.DataInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

public class Assign5SetA4 {
  public static void main(String[] args) {
    try {
      Class.forName("org.postgresql.Driver");

    
      Connection cn = DriverManager.getConnection("jdbc:postgresql:test","postgres","");

      DataInputStream KB = new DataInputStream(System.in);

     
      System.out.print("Enter Employee ID: ");
      String eid = KB.readLine();
      
     
      System.out.print("Enter Employee Name: ");
      String en = KB.readLine();
      
    
      System.out.print("Enter Employee Salary: ");
      String es = KB.readLine();


      PreparedStatement smt = cn.prepareStatement("insert into employee values(?,?,?)");

      
      smt.setInt(1, Integer.parseInt(eid));
      smt.setString(2, en);
      smt.setInt(3, Integer.parseInt(es));

      
      smt.executeUpdate();
      System.out.println("Record Submitted....");

      
      cn.close();
    } catch (Exception e) {
      System.out.println(e);
    }
  }
}

