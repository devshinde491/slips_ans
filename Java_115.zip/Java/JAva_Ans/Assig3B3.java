import java.io.*;
import java.util.Scanner;

public class Assig3B3 {

 public static void main(String[] args) {
 Scanner scanner = new Scanner(System.in);
 String fileName = "customers.dat";
   try (DataOutputStream dos = new DataOutputStream(new FileOutputStream(fileName))) {
       System.out.print("Enter the number of customers: ");
       int n = scanner.nextInt();
       scanner.nextLine(); 
    for (int i = 0; i < n; i++) {
       System.out.println("Enter details for customer " + (i + 1) + ":");
       System.out.print("Customer ID: ");
       int c_id = scanner.nextInt();
       scanner.nextLine(); 

	System.out.print("Customer Name: ");
	String cnames = scanner.nextLine();
	System.out.print("Address: ");
	String address = scanner.nextLine();
	System.out.print("Mobile Number: ");
	String mobile_no = scanner.nextLine();
	dos.writeInt(c_id);
	dos.writeUTF(cnames);
	dos.writeUTF(address);
	dos.writeUTF(mobile_no);
            }
        } catch (IOException e) {
            System.err.println("Error writing to file: " + e.getMessage());
        }


        try (DataInputStream dis = new DataInputStream(new FileInputStream(fileName))) {
            System.out.println("\nCustomer Details:");

            while (true) {
                try {
	int c_id = dis.readInt();
	String cnames = dis.readUTF();
	String address = dis.readUTF();
	String mobile_no = dis.readUTF();

	System.out.println("Customer ID: " + c_id);
	System.out.println("Customer Name: " + cnames);
	System.out.println("Address: " + address);
	System.out.println("Mobile Number: " + mobile_no);
	System.out.println();
	} catch (EOFException e) {

                    break;
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading from file: " + e.getMessage());
        }

        scanner.close();
    }
}

