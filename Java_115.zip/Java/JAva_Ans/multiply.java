import java.io.*;
public class multiply
{
public static void main(String[] args)throws IOException
{
int num;
int i;

	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	System.out.println("Enter the number");
	num=Integer.parseInt(br.readLine());
	for(i=1;i<=10;i++){
	
	System.out.println(num+"*"+i+"=\t"+num*i);
}
}
}

 
