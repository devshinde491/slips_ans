import java.sql.*;
import java.io.*;
public class As5a1
{
public static void main(String args[])throws Exception
{
Class.forName("org.postgresql.Driver");
ResultSet rs=null;
try
{
Connection con=DriverManager.getConnection("jdbc:postgresql:test5","postgres","");
if(con==null)
System.out.println("Connection failed");
else
{
System.out.println("Connection failed");
Statement smt = con.createStatement();
rs=smt.executeQuery("Select * from test");
while(rs.next())
{
System.out.println("pid="+rs.getInt(1));
System.out.println("pname="+rs.getString(2));
System.out.println("gender="+rs.getString(3));
System.out.println("birth_date="+rs.getInt(4));
}
con.close();
}
}
catch(Exception e)
{
System.out.println(e);
}
}
}
