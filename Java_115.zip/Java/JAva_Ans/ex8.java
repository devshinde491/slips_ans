import java.io.*;
import java.util.*;
class ex8{

	public static void main(String args[]){
                                 
                              	int num[]=new int[args.length];
                              	for(int i=0;i<args.length;i++){
					num[i]=Integer.parseInt(args[i]);
                              	}
                              	
                              	
                              	for(int i=0;i<args.length;i++){
                                  System.out.println("num["+i+"]="+num[i]);
                              	}
                              	                                  System.out.println("sorted");
                              	for(int i=0;i<args.length;i++){
        			 for(int j=i+1;j<args.length;j++){
        			 if(num[i]>num[j]){
        			   int temp=num[i];
        			   num[i]=num[j];
        			   num[j]=temp;
        			}                     	}
                              	}
                              	for(int i=0;i<args.length;i++){
                                  System.out.println("num["+i+"]="+num[i]);
                              	}


}
}
