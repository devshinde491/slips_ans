public class add
{
int a=10;
int b=20;
public void sum()
{
int c;
c=a+b;
System.out.println("addition is"+c);
}
public static void main(String args[])
{
add obj=new add();
obj.a=25;
obj.b=30;
obj.sum();
}
}
