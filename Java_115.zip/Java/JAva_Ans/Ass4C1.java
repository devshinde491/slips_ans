import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class Ass4C1 
{
public static void main(String[] args)
	{
		JFrame frame=new JFrame("notepad");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(500,500);
JMenuBar menuBar=new JMenuBar();
JMenu fileMenu=new JMenu("file");
JMenu editMenu=new JMenu("edit");
JMenu helpMenu=new JMenu("help");
menuBar.add(fileMenu);
menuBar.add(editMenu);
menuBar.add(helpMenu);
JMenuItem cutItem=new JMenuItem("Cut");
JMenuItem copyItem=new JMenuItem("Copy");
JMenuItem pasteItem=new JMenuItem("Paste");
JMenuItem selectAllItem=new JMenuItem("Select All");
editMenu.add(cutItem);
editMenu.add(copyItem);
editMenu.add(pasteItem);
editMenu.add(selectAllItem);
final JTextArea textArea=new JTextArea();
JScrollPane scrollPane= new JScrollPane(textArea);

cutItem.addActionListener(new ActionListener() {
public void actionPerformed(ActionEvent e) {
textArea.cut();
}
});
copyItem.addActionListener(new ActionListener() {
public void actionPerformed(ActionEvent e) {
textArea.copy();
}
});
pasteItem.addActionListener(new ActionListener() {
public void actionPerformed(ActionEvent e) {
textArea.paste();
}
});
selectAllItem.addActionListener(new ActionListener() {
public void actionPerformed(ActionEvent e) {
textArea.selectAll();
}
});
frame.setJMenuBar(menuBar);
frame.add(scrollPane,BorderLayout.CENTER);
frame.setVisible(true);
}
}


