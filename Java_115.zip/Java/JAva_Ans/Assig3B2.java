import java.util.Scanner;
import java.util.regex.Pattern;

class InvalidNameException extends Exception {
    public InvalidNameException(String message) {
        super(message);
    }
}

public class Assig3B2 {

    public static boolean isValidName(String name) {
        String regex = "^[a-zA-Z\\s]+$";
        return Pattern.matches(regex, name);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the doctor's name: ");
        String doctorName = scanner.nextLine();

        try {
            if (!isValidName(doctorName)) {
                throw new InvalidNameException("Name is invalid. It should not contain digits or special symbols.");
            }
            
            System.out.println("Doctor's name is valid: " + doctorName);
        } catch (InvalidNameException e) {
            System.out.println(e.getMessage());
        } finally {
            scanner.close();
        }
    }
}
