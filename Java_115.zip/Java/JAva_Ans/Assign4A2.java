import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Assign4A2 {

    public static void main(String[] args) {
     
        JFrame frame = new JFrame("Vaccination Details");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(350, 300);
        frame.setLocationRelativeTo(null);


        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        frame.add(panel);


        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;


        JLabel nameLabel = new JLabel("Name:");
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(nameLabel, gbc);

        JTextField nameText = new JTextField(20);
        gbc.gridx = 1;
        gbc.gridy = 0;
        panel.add(nameText, gbc);


        JLabel doseLabel = new JLabel("Dose:");
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(doseLabel, gbc);

        JCheckBox firstDoseCheckbox = new JCheckBox("1st Dose");
        gbc.gridx = 1;
        gbc.gridy = 1;
        panel.add(firstDoseCheckbox, gbc);

        JCheckBox secondDoseCheckbox = new JCheckBox("2nd Dose");
        gbc.gridx = 1;
        gbc.gridy = 2;
        panel.add(secondDoseCheckbox, gbc);


        JLabel vaccineLabel = new JLabel("Vaccine:");
        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(vaccineLabel, gbc);

        JCheckBox covishieldCheckbox = new JCheckBox("Covishield");
        gbc.gridx = 1;
        gbc.gridy = 3;
        panel.add(covishieldCheckbox, gbc);

        JCheckBox covaxinCheckbox = new JCheckBox("Covaxin");
        gbc.gridx = 1;
        gbc.gridy = 4;
        panel.add(covaxinCheckbox, gbc);

        JCheckBox sputnikVCheckbox = new JCheckBox("Sputnik V");
        gbc.gridx = 1;
        gbc.gridy = 5;
        panel.add(sputnikVCheckbox, gbc);

        
        JButton submitButton = new JButton("Submit");
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 2;
        panel.add(submitButton, gbc);

        JButton resetButton = new JButton("Reset");
        gbc.gridx = 1;
        gbc.gridy = 6;
        panel.add(resetButton, gbc);


        submitButton.addActionListener(new ActionListener() {
         
            public void actionPerformed(ActionEvent e) {
                String name = nameText.getText();
                boolean firstDose = firstDoseCheckbox.isSelected();
                boolean secondDose = secondDoseCheckbox.isSelected();
                boolean covishield = covishieldCheckbox.isSelected();
                boolean covaxin = covaxinCheckbox.isSelected();
                boolean sputnikV = sputnikVCheckbox.isSelected();

                StringBuilder message = new StringBuilder("Vaccination Details:\n");
                message.append("Name: ").append(name).append("\n");
                message.append("1st Dose: ").append(firstDose ? "Yes" : "No").append("\n");
                message.append("2nd Dose: ").append(secondDose ? "Yes" : "No").append("\n");
                message.append("Vaccines: ");
                if (covishield) message.append("Covishield ");
                if (covaxin) message.append("Covaxin ");
                if (sputnikV) message.append("Sputnik V ");
                if (message.toString().endsWith("Vaccines: ")) {
                    message.append("None");
                }
                JOptionPane.showMessageDialog(frame, message.toString());
            }
        });

        resetButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                nameText.setText("");
                firstDoseCheckbox.setSelected(false);
                secondDoseCheckbox.setSelected(false);
                covishieldCheckbox.setSelected(false);
                covaxinCheckbox.setSelected(false);
                sputnikVCheckbox.setSelected(false);
            }
        });

        frame.setVisible(true);
    }
}

