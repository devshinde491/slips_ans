import java.io.*;
import java.util.*;
class ex1{
       

   
	public static void main(String args[]){
                              	Scanner scan=new Scanner(System.in);
                              	System.out.println("enter the numebr");
                              	int num=scan.nextInt();
                              	for(int i=1;i<=10;i++){
                              	System.out.println(num+"*"+i+"="+num*i);
                              	
                              	}
              	
	
	}


}
