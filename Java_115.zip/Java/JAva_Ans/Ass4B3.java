import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class Ass4B3 {
private JTextField displayField;
private double firstOperand=0;
private double secondOperand=0;
private String operator="";
private boolean startNewNumber=true;

public Ass4B3(){
JFrame frame=new JFrame("Calculator");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(300,400);
		
displayField=new JTextField();
displayField.setEditable(false);
displayField.setHorizontalAlignment(JTextField.RIGHT);
displayField.setPreferredSize(new Dimension(280,50));
JPanel buttonPanel=new JPanel();
buttonPanel.setLayout(new GridLayout(5,4,5,5));
String[]buttonLabels= {
"7","8","9","/",
"4","5","6","*",
"1","2","3","-",
"0",".","=","+",
"clear"
};
for(String label:buttonLabels){
JButton button=new JButton(label);
button.addActionListener(new ButtonClickListener());
buttonPanel.add(button);
}
frame.add(displayField,BorderLayout.NORTH);
frame.add(buttonPanel,BorderLayout.CENTER);
frame.setVisible(true);
}
private class ButtonClickListener implements ActionListener{
public void actionPerformed(ActionEvent e){
String command=e.getActionCommand();

if(command.matches("[0-9.]")){
if(startNewNumber){
displayField.setText(command);
startNewNumber=false;

}else{
displayField.setText(displayField.getText()+command);
}
}

else if(command.matches("[/*\\-+]")){
firstOperand=Double.parseDouble(displayField.getText());
operator=command;
startNewNumber=true;
}

else if(command.equals("=")){
secondOperand=Double.parseDouble(displayField.getText());
double result=0;

switch(operator){
case "+":
result=firstOperand + secondOperand;
break;
case "-":
result=firstOperand - secondOperand;
break;
case "*":
result=firstOperand * secondOperand;
break;
case "/":
if(secondOperand!=0) {
result=firstOperand / secondOperand;
} else{
JOptionPane.showMessageDialog(null,"cannot divide by zero");
return;
}
break;
}
displayField.setText(String.valueOf(result));
startNewNumber=true;
}
else if(command.equals("clear")){
displayField.setText("");
firstOperand=0;
secondOperand=0;
operator="";
startNewNumber=true;
}
}
}
public static void main(String[] args){
new Ass4B3();
}
}


		
