import java.sql.*;
import java.io.*;
public class Ass5A2
{
public static void main(String args[])throws Exception{
try {
Class.forName("org.postgresql.Driver");
Connection con=DriverManager.getConnection("jdbc:postgresql:test","postgres","");

PreparedStatement ps=con.prepareStatement("select * from person");
ResultSet rs=ps.executeQuery();
ResultSetMetaData rsmd=rs.getMetaData();

System.out.println("Total columns:"+rsmd.getColumnCount());
System.out.println("Column name of 1st column:"+rsmd.getColumnName(1));
System.out.println("Column type name of 1st column:"+rsmd.getColumnTypeName(1));

System.out.println("Column name of 2nd column:"+rsmd.getColumnName(2));
System.out.println("Column type name of 2nd column:"+rsmd.getColumnTypeName(2));

System.out.println("Column name of 3rd column:"+rsmd.getColumnName(3));
System.out.println("Column type name of 3rd column:"+rsmd.getColumnTypeName(3));

System.out.println("Column name of 4th column:"+rsmd.getColumnName(4));
System.out.println("Column type name of 4th column:"+rsmd.getColumnTypeName(4));

con.close();
}catch(Exception e){System.out.println(e);
}
}
}
