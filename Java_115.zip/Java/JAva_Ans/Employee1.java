class Employee
{
String name;
double salary;
public Employee(String name,double salary)
{
this.name=name;
this.salary=salary;
}
public void displayDetails(){
System.out.println("name:"+name);
System.out.println("salary:"+salary);
}
}
class Developer extends Employee {
String projectName;
public Developer(String name, double salary, String projectName){
super(name,salary);
this.projectName=projectName;
}
public void displayDetails(){
super.displayDetails();
System.out.println("project name:"+projectName);
}
}
class Programmer extends Developer{
String progLanguage;
public Programmer(String name,double salary,String projectName,String progLanguage){
super(name,salary,projectName);
this.progLanguage=progLanguage;
}
public void displayDetails(){
super.displayDetails();
System.out.println("programming language:"+progLanguage);
}
}
class Employee1
{
public static void main(String args[])
{
Developer dev=new Developer("alice",80000,"project apollo");
dev.displayDetails();
}
}
