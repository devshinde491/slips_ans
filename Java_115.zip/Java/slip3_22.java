import java.io.*;
import java.util.Scanner;

public class slip3_22{
	public static void main(String args[]){
		try{
			Scanner input = new Scanner(new File("input.txt"));
			PrintWriter writer = new PrintWriter(new FileWriter("output.txt"));
			
			while(input.hasNextLine()){
				String line = input.nextLine();
				writer.println(line.toUpperCase());
				}
			
			input.close();
			writer.close();
			
			System.out.println("File content copy into another file and covert into uppercase");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}	
