public class slip11_1{
	int dd,mm,yy;
	
	slip11_1(int dd, int mm, int yy){
		this.dd = dd;
		this.mm = mm;
		this.yy = yy;
	}
	
	void display(){
		System.out.println("Date: " + this.dd + "-" + this.mm + "-" + this.yy);
	}
	
	public static void main(String args[]){
		slip11_1 sp = new slip11_1(29, 01, 2001);
		sp.display();
	}
}		
			
