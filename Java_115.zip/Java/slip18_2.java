import java.io.*;

public class slip18_2 {
    public static void main(String args[]) throws IOException {
        String FileName = "input.txt";
        try (BufferedReader input = new BufferedReader(new FileReader(FileName))) {
            String line;
            while ((line = input.readLine()) != null) {
                System.out.println(line.toUpperCase());
            }
        } catch (Exception e) {
            System.out.println("Error occurred when file reading: " + e.getMessage());
        }
    }
}
