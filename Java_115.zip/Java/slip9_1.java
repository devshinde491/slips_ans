import java.io.*;

public class slip9_1{
	public static void main(String args[]) throws Exception{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Enter a number: ");
		int num = Integer.parseInt(br.readLine());
		
		if(isPerfect(num)){
			System.out.print("Perfect");
			} else{
				System.out.print("Not perfect");
			}
		}		
			
		
		static boolean isPerfect(int num){
			int sum = 0;
			
			for(int i = 1; i<=num/ 2; i++){
				if( num % i == 0){
					sum += i;
				}
			}	
			
			return sum == num;
		}
	}		
