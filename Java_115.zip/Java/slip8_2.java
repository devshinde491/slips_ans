import java.util.*;
class InvalidDateException extends Exception{
	public InvalidDateException(String message){
		super(message);
	}
}

class MyDate{
	int day, month, year;
	void acceptDate() throws InvalidDateException{
		Scanner input = new Scanner(System.in);
		System.out.println("Enter  date (dd mm yyyy): ");
		day = input.nextInt();
		month = input.nextInt();
		year = input.nextInt();
		
		if(month < 1 || month > 12 || day < 1 || day > 31 || (month == 2 && day > 28)){
			throw new InvalidDateException("Invalid date: " + day + "/" + month + "/" + year);
		}
	}
	void display(){
	  System.out.println("Date: " + day + "/"+ month + "/" + year);
	  }
}	

public class slip8_2{
	public static void main(String[] args){
		MyDate date = new MyDate();
		try{
			date.acceptDate();
			date.display();
		} catch (InvalidDateException e){
			System.out.println(e.getMessage());
		}
	}
}				
	
