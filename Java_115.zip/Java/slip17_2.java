class Student {
	int rollno;
	String name;
	static int count = 0;
	
	Student(){
		this.rollno = 0;
		this.name = "ram";
		count++;
	}	
	
	Student(int rollno, String name){
		this.rollno = rollno;
		this.name = name;
		count++;
	}
	
	void display(){
		System.out.println("Roll no : "+ rollno);
		System.out.println("Name : "+ name);
	}
	
	static void displaycount(){
		System.out.println("Total object created: " + count);
	}
}
public class slip17_2{
	public static void main(String []args){
		Student s1 = new Student(101, "ram");
		s1.display();
		s1.displaycount();
		
		Student s2 = new Student(102, "sayali");
		s2.display();
		s2.displaycount();
		
		Student s3 = new Student(103, "Sakshi");
		s3.display();
		s3.displaycount();
	}
}		
				
	
	 
