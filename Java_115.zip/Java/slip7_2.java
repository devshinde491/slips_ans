import java.util.*;

class Student{
	int rollno;
	String name;
	double per;
	
	Student(){
		this.rollno = 0;
		this.name = "";
		this.per =0.0;
	}
	
	Student(int rollno, String name, double per){
		this.rollno = rollno;
		this.name = name;
		this.per = per;
	}
	
	void display(){
		System.out.println("Roll no : " + this.rollno );
		System.out.println("Name : " + this.name );
		System.out.println("Percentage : " + this.per );
	}
}
public class slip7_2{
	public static void main(String args[]){
		Scanner input = new Scanner(System.in);
		
		Student[] stud = new Student[5];
		
		for(int i= 0; i<5; i++){
			System.out.println("Enter roll number: ");
			int rollno = input.nextInt();
			input.nextLine();
			System.out.println("Enter name:");
			String name = input.nextLine();
			System.out.println("Enter Percentage: ");
			double per = input.nextDouble();
			
			stud[i] = new Student(rollno, name, per);
		}
		
		for(Student s: stud){
			s.display();
		}
	}
}			
