import java.util.*;
class a3sb1
{
public static void main(String[]args)
{
LinkedList ll=new LinkedList();
ll.add("Red");
ll.add("Blue");
ll.add("yellow");
ll.add("Orange");
Iterator i=ll.iterator();
System.out.println("contents of the list using an Iterator");
while(i.hasNext())
{
String s=(String)i.next();
System.out.println(s);
}
ListIterator litr=ll.listIterator();
while(litr.hasNext())
{
String elt=(String)litr.next();
}
System.out.println("contents of the List in reverse order using a ListIterator");
while(litr.hasPrevious())
{
System.out.println(litr.previous());
}
ll.add(2,"Pink");
ll.add(3,"Green");
System.out.println("list between blue and yellow is");
System.out.println(ll);
}
}
