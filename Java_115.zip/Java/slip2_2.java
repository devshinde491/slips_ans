public class slip2_2{
	private int value;
	public slip2_2(int val){
		value = val;
		}
	
	public boolean isNegative(){
		return value < 0;
		}
		
	public boolean isPositive(){
		return value > 0;
		}
	
	public boolean isOdd(){
		return value % 2 != 0;
		}
		
	public boolean isEven(){
		return value % 2 == 0;
		}
	
	public static void main(String args[]){
		int n = Integer.parseInt(args[0]);
		
		slip2_2 myNum = new slip2_2(n);
		
		System.out.println("Is Negative: "+ myNum.isNegative());
		System.out.println("Is Positive: "+ myNum.isPositive());
		System.out.println("Is Even: "+ myNum.isEven());
		System.out.println("Is Odd: "+ myNum.isOdd());
	}
}
	
