class Point {
	int x,y;
	
	Point(int x, int y){
		this.x=x;
		this.y=y;
	}
	
	void display(){
		System.out.println("Point: (" + x + ", " + y + ")");
	}
}
class Point3D extends Point{
	int z;
	
	Point3D(int x, int y, int z){
		super(x,y);
		this.z= z;
	}
	
	void display(){
		super.display();
		System.out.println("Age: "+z);
	}
}

public class slip9_2{
	public static void main(String[] args){
		Point3D cp = new Point3D(4, 5, 35);
		cp.display();
	}
}		
		
