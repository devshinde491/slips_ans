package series;

public class SquareSeries{
	public void print_series(int n){
		for(int i=1; i<=n; i++){
			System.out.println(i + "^2 = " + (i * i));
			}
		}
	}
