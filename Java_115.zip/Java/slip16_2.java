class Employee{
 	String name;
 	double salary;
 	
 	Employee(String name, double salary){
 		this.name = name;
 		this.salary = salary;
 	}
 }
 
class Programmer extends Employee{
	String language;
	
	Programmer(String name, double salary, String language){
		super(name, salary);
		this.language = language;
	}
	
	void display(){
		System.out.println("Emp Name : " + name);
		System.out.println("Emp Salary : " + salary);
		System.out.println("Emp Language : " + language);
	}
}
public class slip16_2{
	public static void main(String args[]){
		Programmer d = new Programmer("Rameshwar", 500000, "Java");
		d.display();
	}
}			
		
