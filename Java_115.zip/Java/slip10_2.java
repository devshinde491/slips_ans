import utility.CapitalString;

public class slip10_2{
	String name, city;
	
	public slip10_2(String name, String city){
		this.name = name;
		this.city = city;
	}	
	public void display(){
		System.out.println("Name: "+ CapitalString.capatalizeFirstLetter(name));
		System.out.println("City: " + city);
	}
	
	public static void main(String[] args){
		slip10_2 sp = new slip10_2("John", "New york");
		sp.display();
	}
}					


