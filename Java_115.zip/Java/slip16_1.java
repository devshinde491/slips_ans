class MyNumber {
	int number;
	MyNumber(int number){
		this.number = number;
	}
	boolean isEven(){
		return number % 2 == 0;
	}	
}
public class slip16_1{
	public static void main(String args[]){
		int num = Integer.parseInt(args[0]);
		MyNumber mn = new MyNumber(num);
		
		if(mn.isEven()){
			System.out.println(num + " is Even");
		} else { 
			System.out.println(num + " is Odd");
		}
	}
}		

