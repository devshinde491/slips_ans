abstract class Shape{
	abstract double area();
	abstract double volume();
}

class Sphere extends Shape{
	double radius;
	
	Sphere(double radius){
		this.radius = radius;
	}
	
	double area(){
		return 4 * Math.PI * radius * radius;
	}
	
	double volume(){
		return (4.0/3) * Math.PI * radius * radius * radius;	
	}
}

public class slip11_2{
	public static void main(String args[]){
		Sphere sp = new Sphere(5);		
		System.out.println("Area of Circle: " + sp.area());
		System.out.println("Volume of Sphere: "+ sp.volume());
	}
}		
