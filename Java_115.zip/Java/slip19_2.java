import java.util.*;

abstract class Order{
	int id;
	String desc;
	
	abstract void accept();
	abstract void display();
}

class Purchase_order extends Order{
	String cname;
	
	void accept(){
		Scanner input= new Scanner(System.in);
		System.out.println("Enter order iD: ");
		id = input.nextInt();
		input.nextLine();
		System.out.println("Enter order Description: ");
		desc = input.nextLine();
		System.out.println("Enter Customer Name: ");
		cname = input.nextLine();
	}
	
	void display(){
		System.out.println("Order ID: " + id);
		System.out.println("Order Desc: " + desc);
		System.out.println("Order Customer Name: " + cname);
	}
}

public class slip19_2{
	public static void main(String args[]){
		Purchase_order po[] = new Purchase_order[3];
		for(int i=0; i<3; i++){
			po[i] = new Purchase_order();
			po[i] .accept();
		}
		
		for(Purchase_order p : po){
			p.display();
		}
	}
}			
