class Point {
	int x,y;
	
	Point(int x, int y){
		this.x=x;
		this.y=y;
	}
	
	void display(){
		System.out.println("Point: (" + x + ", " + y + ")");
	}
}
class ColorPoint extends Point{
	String color;
	
	ColorPoint(int x, int y, String color){
		super(x,y);
		this.color= color;
	}
	
	void display(){
		super.display();
		System.out.println("Color: "+color);
	}
}

public class slip5_2{
	public static void main(String[] args){
		ColorPoint cp = new ColorPoint(4, 5, "Red");
		cp.display();
	}
}		
		
