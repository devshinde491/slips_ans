import java.util.*;

class ZeroException extends Exception{
	public ZeroException(String message){
		super(message);
	}
}

public class slip5_1{
	public static void main(String args[]){
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the number: ");
		int number = input.nextInt();
		
		try{
			if(number == 0){	
				throw new ZeroException("Number is 0");
			}
			
			int fact = 1;
			for(int i=1; i<=number; i++){
				fact *= i;
			}
			System.out.println("Factorial of " + number + " is: "+ fact );
		} catch (ZeroException e) {
			System.out.println(e.getMessage());
		}
	}
}	
			
			
