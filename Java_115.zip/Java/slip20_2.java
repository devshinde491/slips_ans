class Employee {
	int id;
	String name, dept;
	double salary;
	static int count = 0;
	
	Employee(){
		this.id = 1;
		this.name = "ram";
		this.dept = "CA";
		this.count = 0;
	}
	
	Employee(int id, String name, String dept, double salary){
		this.id = id;
		this.name = name;
		this.dept = dept;
		this.salary = salary;
		count++;
		System.out.println("Object Count: " + count);
	}
	
	void display(){
		System.out.println("ID: " + id);
		System.out.println("Name: " + name);
		System.out.println("Dept: " + dept);
		System.out.println("Salary: " + salary);
	}
}
public class slip20_2{
	public static void main(String args[]){
		Employee e1 = new Employee(101, "ram", "HR", 50000.0);
		e1.display();
		
		Employee e2 = new Employee(102, "rammzz", "Finance", 60000.0);
		e2.display();
		
		Employee e3 = new Employee(103, "rameshwar", "IT", 70000.0);
		e3.display();
	}
}
