interface Operation { 
	void area();
	void volume();
	double PI = 3.14;
}
class Circle implements Operation{
	double radius;
	Circle(double radius){
		this.radius = radius;
	}
	
	public void area(){
		System.out.println("Area of Circle: " + (PI * radius * radius));
	}
	
	public void volume(){
		System.out.println("Circle of Volume: " + ((4.0 / 3 ) * radius * radius * radius));
	}
}
public class slip13_2{
	public static void main(String []args){
		Circle c = new Circle(5.0);
		c.area();
		c.volume();
	}
}		
