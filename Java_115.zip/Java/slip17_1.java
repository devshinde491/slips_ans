class MyNumber {
	int number;
	MyNumber(int number){
		this.number = number;
	}
	boolean isOdd(){
		return number % 2 != 0;
	}	
}
public class slip17_1{
	public static void main(String args[]){
		int num = Integer.parseInt(args[0]);
		MyNumber mn = new MyNumber(num);
		
		if(mn.isOdd()){
			System.out.println(num + " is Odd");
		} else { 
			System.out.println(num + " is Even");
		}
	}
}		

