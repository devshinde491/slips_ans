class Employee{
 	String name;
 	double salary;
 	
 	Employee(String name, double salary){
 		this.name = name;
 		this.salary = salary;
 	}
 }
 
class Developer extends Employee{
	String project;
	
	Developer(String name, double salary, String project){
		super(name, salary);
		this.project = project;
	}
	
	void display(){
		System.out.println("Emp Name : " + name);
		System.out.println("Emp Salary : " + salary);
		System.out.println("Emp Project : " + project);
	}
}
public class slip15_2{
	public static void main(String args[]){
		Developer d = new Developer("Rameshwar", 500000, "Job_Platform");
		d.display();
	}
}			
		
