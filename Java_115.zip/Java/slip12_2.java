abstract class Shape{
	abstract double area();
	abstract double volume();
}

class Cylinder extends Shape{
	double radius, height;
	
	Cylinder(double radius, double height){
		this.radius = radius;
		this.height = height;
	}
	
	double area(){
		return 2 * Math.PI * radius * (radius + height);
	}
	
	double volume(){
		return Math.PI * radius * radius * height;
	}
}	

public class slip12_2{
	public static void main(String[] args){
		Cylinder cy = new Cylinder(5, 10);
		System.out.println("Area of Cylinder: " + cy.area());
		System.out.println("Volune of Cylinder: " + cy.volume());
	}
}	
		
