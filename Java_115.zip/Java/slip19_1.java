import java.util.*;

public class slip19_1 {
	public static void main(String args[]){
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the number of Array element:");
		int n = input.nextInt();
		
		int arr[] = new int[5];
		
		System.out.println("Enter "+n+" numbers");
		
		for(int i=0; i<n; i++){
			arr[i] = input.nextInt();
		}
		
		int max = arr[0];
		for(int i=0; i<n; i++){
			if(arr[i] > max){
				max = arr[i];
			}
		}
		
		System.out.println("Maximum number: " + max);
	}
}			
