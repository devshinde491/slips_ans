import java.util.*;

public class slip20_1 {
	public static void main(String args[]){
		int arr[] = new int[3];
		
		for(int i=0; i<3; i++){
			arr[i] = Integer.parseInt(args[i]);
		}
		
		Arrays.sort(arr);
		
		for(int i=0; i<3; i++){
			System.out.println(arr[i]);
		}
	}	
}	
