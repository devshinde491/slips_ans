import java.util.*;

public class slip4_1{
	public static void main(String args[]){
		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter your name: ");
		String name = input.nextLine();
		
		String upperName = name.toUpperCase();
		System.out.println("Hello, " +upperName + ", nice to meet you! ");
		}
	}
