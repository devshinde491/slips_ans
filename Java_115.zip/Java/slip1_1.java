public class slip1_1 {
	public static void main(String[] args){
		int n;
		System.out.println("Enter the number:");
		n = Integer.parseInt(args[0]);
		
		for(int i=1; i<11; i++){
			System.out.println((i * n));
			}
		}
	}
