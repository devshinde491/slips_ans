import java.util.*;

class Employee{
	String name;
	double salary;
	
	Employee(String n, double sal){
		name = n;
		salary = sal;
	}
}

public class slip6_2{
	public static void main(String args[]){
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the number of employees: ");
		int n = input.nextInt();
		input.nextLine(); 
		
		Employee[] employees = new Employee[n];
		
		for(int i=0; i<n; i++){
			System.out.println("Enter employee name: ");
			String name = input.nextLine();
			System.out.println("Enter employee salary : ");
			double salary = input.nextDouble();
			input.nextLine(); 
			employees[i] = new Employee(name, salary);	
		}
		Employee maxEmp = employees[0];
		for(int i = 1; i<n; i++){
			if(employees[i].salary > maxEmp.salary){
				maxEmp = employees[i];
			}
		}
		System.out.println("Employee with highest salary: " + maxEmp.name);
	}
}
