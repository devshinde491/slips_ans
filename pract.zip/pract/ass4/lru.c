//LRU
#include<stdio.h>
int nor,nof,refstring[30],F[10]; 
void accept()
{
 int i;
  printf("\nEnter the Reference String:\n ");
  for(i=0;i<nor;i++)
  {
   printf("[%d]: ",i); 
   scanf("%d",&refstring[i]);
  }
}
int search(int page)
{
  int i;
    for(i=0;i<nof;i++)
    {
      if(page==F[i])
         return i;
    }
 return -1;
            
}
int getfno(int i)
{
  int fno,prev,pos=99,fpos;
  for(fno=0;fno<nof;fno++)
  {
     for(prev=i-1;prev>=0;prev--)
     {
         if(F[fno]==refstring[prev])
         {
           if(prev<pos) 
           {
             pos=prev; 
             fpos=fno;  
           }
          break;
        }
    }
 }
 return fpos; 

}
void LRU()
{
  int i,j,k,fno,fault=0; 
  for(fno=0,i=0;fno<nof && i<nor;i++)
  {
    printf("\n%d",refstring[i]); 
    k=search(refstring[i]); 

   if(k==-1)
   {
      F[fno]=refstring[i];
      for(j=0;j<nof;j++)
      {
         if(F[j])
          printf("\t%d",F[j]);
      }
     fault++;
     fno++;
   }
  }
 while(i<nor)
 {
    printf("\n%d",refstring[i]);
    k=search(refstring[i]);

   if(k==-1)
   {
      fno=getfno(i);
      F[fno]=refstring[i];
      for(j=0;j<nof;j++)
      {
         if(F[j])
          printf("\t%d",F[j]);
      }
     fault++;
     
   }
  i++;

 } 
  printf("\nTotal no of Page fault: %d",fault);

  
}
main()
{
  printf("\nEnter the Length of the string: ");
  scanf("%d",&nor);
  printf("\nEnter no. of Frames: ");
  scanf("%d",&nof);
  accept();
  LRU();
}
