#include<stdio.h>
int nor,nof,refstring[30],F[10]; 
void accept()
{
 int i;
  printf("\nEnter the Reference String:\n ");
  for(i=0;i<nor;i++)
  {
   printf("[%d]: ",i); 
   scanf("%d",&refstring[i]);
  }
}
int search(int page)
{
  int i;
    for(i=0;i<nof;i++)
    {
      if(page==F[i])
         return i;
    }
 return -1;
            
}
void FIFO()
{
  int i,j,k,fno=0,fault=0; 
  for(i=0;i<nor;i++)
  {
    printf("\n%d",refstring[i]); 
    k=search(refstring[i]); 
    //printf("\nk=%d",k); 
   if(k==-1)
   {
      F[fno]=refstring[i];
      for(j=0;j<nof;j++)
      {
         if(F[j])
          printf("\t%d",F[j]);
      }
     fault++;
     fno=(fno+1)%nof;
   }
  }
  printf("\nTotal no of Page fault: %d",fault);
}main()
{
  printf("\nEnter the Length of the string: ");
  scanf("%d",&nor);
  printf("\nEnter no. of Frames: ");
  scanf("%d",&nof);
  accept();
  FIFO();
}
