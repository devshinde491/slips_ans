#include <stdio.h>
#include <unistd.h>

int main() {
    printf("Child Process is : (PID: %d)\n", getpid());
    return 0;
}
