#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
    pid_t pid;

    // Fork a child process
    pid = fork();

    if (pid < 0) {
        // Fork failed
        perror("Fork failed");
        return 1;
    } else if (pid == 0) {
        // Child process
        printf("Child Process (PID: %d)\n", getpid());
        // Replace the child process with the "ls" command
        execl("/bin/ls", "ls", NULL);
        // If execl returns, it must have failed
        perror("execl failed");
        return 1;
    } else {
        // Parent process
        printf("Parent Process (PID: %d)\n", getpid());
        // Wait for the child process to finish
        wait(NULL);
        printf("Child process terminated, control returned to parent.\n");
    }

    return 0;
}
