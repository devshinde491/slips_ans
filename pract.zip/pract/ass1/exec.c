#include<stdio.h>
#include<unistd.h>
main()
{

printf("I am in exec.c file ");
printf("\nPID of exec.c : %d",getpid());
char *args[]={"./hello",NULL};
execv(args[0],args);
printf("\nComing back to exec.c");
}
