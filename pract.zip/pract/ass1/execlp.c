#include<sys/types.h>
#include<stdio.h>
#include<unistd.h>
int main()
{
int pid;
pid = fork(); /* fork a child process */
if (pid< 0) /* error occurred */
{
  printf("Fork Failed");
return 1;
}
else if (pid == 0) /* child process */
execlp("/bin/ls","ls",NULL);
else /* parent process */
{
wait(NULL); /* parent will wait for the child to complete */
printf("Child Complete");
}
return 0;
}
