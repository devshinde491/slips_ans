#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
int main()
 {
    printf("Parent Process (PID: %d)\n", getpid());
    // Replace the current process with the child process
    execl("./child", "child",NULL);
    // If execl returns, it must have failed
    printf("\nReturn to Parent process.");
    perror("execl failed");
    return 1;
}
