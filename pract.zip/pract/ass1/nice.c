#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <errno.h>
int main() {
    pid_t pid;
    // Fork a child process
    pid = fork();
    if (pid < 0)
    {
        // Fork failed
        perror("Fork failed");
        return 1;
    } 
else if (pid == 0)
 {

        printf("Child Process (PID: %d) with initial priority: %d\n", getpid(), getpriority(PRIO_PROCESS, 0));

        // Increase the priority of the child process
        if (nice(-10) == -1 && errno != 0) 
       {
            perror("nice() failed");
            return 1;
        }
        printf("Child Process (PID: %d) with new priority: %d\n", getpid(), getpriority(PRIO_PROCESS, 0));
        // Simulate some work by sleeping
        sleep(5);
        printf("Child Process (PID: %d) completed\n", getpid());
    } 
    else
    {
        // Parent process
        printf("Parent Process (PID: %d) with initial priority: %d\n", getpid(), getpriority(PRIO_PROCESS, 0));
        // Wait for the child process to finish
        wait(NULL);
        printf("Parent Process (PID: %d) after child termination\n", getpid());
    }

    return 0;
}
