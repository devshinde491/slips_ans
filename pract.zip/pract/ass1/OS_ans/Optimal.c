#include<stdio.h>
int nor,nof,refstring[30],F[10];
void accept()
{
	int i;
	printf("\nEnter the reference string:\n");
	for(i=0;i<nor;i++)
	{
		printf("[%d]: ",i);
		scanf("%d",&refstring[i]);
	}
}

int search(int page)
{
	int i;
	for(i=0;i<nof;i++)
	{
		if(page==F[i])
			return i;
	}
	return -1;
}

int getfno(int i)
{
	int fno,prev,pos=0,fpos,flag;
	for(fno=0;fno<nof;fno++)
	{
		flag=0;
		for(prev=i+1;prev<nor;prev++)
		{
			if(F[fno]==refstring[prev])
			{
				flag=1;
				if(prev>pos)
				{
					pos=prev;
					fpos=fno;
				}
				break;
			}
		}
		if(flag==0)
		{
			fpos=fno;
			break;
		}
	}
	return fpos;
}

void optimal()
{
	int i,j,k,fno,fault=0;
	for(fno=0,i=0;fno<nof && i<nor;i++)
	{
		printf("\n%d",refstring[i]);
		k=search(refstring[i]);
		if(k==-1)
		{
			F[fno]=refstring[i];
			for(j=0;j<nof;j++)
			{
				if(F[j])
					printf("\t%d",F[j]);
			}
			fault++;
			fno++;
		}
	}
	while(i<nor)
	{
		printf("\n%d",refstring[i]);
		k=search(refstring[i]);
		if(k==-1)
		{
			fno=getfno(i);
			F[fno]=refstring[i];
			for(j=0;j<nof;j++)
			{
				if(F[j])
					printf("\t%d",F[j]);
			}
			fault++;
		}
		i++;
	}
	printf("\nTotal no of Page Fault: %d",fault);
}

void main()
{
	printf("\nEnter the length of reference string: ");
	scanf("%d",&nor);
	printf("\nEnter the number of frames: ");
	scanf("%d",&nof);
	accept();
	optimal();
}
