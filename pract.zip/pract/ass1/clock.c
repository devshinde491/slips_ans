#include <stdio.h>
#include <time.h>

void sample_instructions()
 {
    long long total = 0;
	int i;
    for (i = 1; i < 10000000; ++i)
   {
        total += i;
    }
    printf("Total: %lld\n", total);
}

int main()
  {
    // Start time
    clock_t start_time = clock();

    // Execute the instructions
    sample_instructions();

    // End time
    clock_t end_time = clock();

    // Calculate the execution time
    double execution_time = ((double) (end_time - start_time)) / CLOCKS_PER_SEC;

    printf("Execution time: %f seconds\n", execution_time);

    return 0;
}
