#include<stdio.h>
void childprocess()
{
printf("\n I am Child Process \n Hello world");
}
void parentprocess()
{
printf("\n I am Parent Process \n Hi");
}
main()
{
int pid;
pid=fork();
if(pid==0)
{
printf("Child Process ID=%d",pid);
childprocess();
}
else
{
printf("\n Parent Process Id=%d",pid);
parentprocess();
}
}
