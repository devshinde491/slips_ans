#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() 
  {
    pid_t pid;

    pid = fork();
    if(pid < 0) 
    {
        perror("Fork failed");
        return 1;
    } 
    else 
    if(pid == 0) 
    {
               sleep(10);
	printf("Child Process (PID: %d, Parent PID: %d)\n", getpid(), getppid());
   
        printf("Child Process (PID: %d) after parent terminated, new Parent PID: %d\n", getpid(), getppid());
    } 
   else 
   {
        printf("Parent Process (PID: %d)\n", getpid());
         sleep(3);
        printf("Parent Process (PID: %d) terminating\n", getpid());
    }
    return 0;
}
