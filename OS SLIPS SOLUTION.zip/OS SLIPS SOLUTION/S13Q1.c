//LAB A1SB2 //Rohit 1127

#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<stdlib.h>
#include<sys/resource.h>
int main()
{
pid_t pid=fork();

if(pid<0)
{
perror("Fork Failed\n");
}
else if(pid==0)
{
printf("child process PID is %d with initial priority %d\n",getpid(),getpriority(PRIO_PROCESS,0));
if(nice(-10)==-1 && perror!=0)
{
perror("nice failed\n");
return 1;

}
printf("child process PID is %d with new prioriy is %d\n",getpid(),getpriority(PRIO_PROCESS,0));
sleep(5);
printf("Child process of PID  %d is completed\n",getpid());
}
else
{
printf("Parent process PID is %d with initial priority %d\n",getpid(),getpriority(PRIO_PROCESS,0));
wait(NULL);
printf("Parent process of PID %d after termination\n",getpid());
}
return 0;
}


