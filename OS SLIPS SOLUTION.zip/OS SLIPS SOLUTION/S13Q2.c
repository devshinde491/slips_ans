//LAB A3SC1 //Rohit 1127

#include <stdio.h>
#include <stdbool.h>

#define P 5 
#define R 4 


void calculateNeed(int need[P][R], int max[P][R], int allocation[P][R]) {
    for (int i = 0; i < P; i++) {
        for (int j = 0; j < R; j++) {
            need[i][j] = max[i][j] - allocation[i][j];
        }
    }
}

bool isSafe(int processes[], int available[], int max[P][R], int allocation[P][R]) {
    int need[P][R];
    calculateNeed(need, max, allocation);

    bool finished[P] = {0};
    int safeSequence[P];
    int work[R];

    for (int i = 0; i < R; i++) {
        work[i] = available[i];
    }

    int count = 0;
    while (count < P) {
        bool found = false;
        for (int p = 0; p < P; p++) {
            if (finished[p] == 0) {
                int j;
                for (j = 0; j < R; j++) {
                    if (need[p][j] > work[j]) {
                        break;
                    }
                }

                if (j == R) {
                    for (int k = 0; k < R; k++) {
                        work[k] += allocation[p][k];
                    }

                    safeSequence[count++] = p;
                    finished[p] = 1;
                    found = true;
                }
            }
        }

        if (found == false) {
            printf("System is not in a safe state.\n");
            return false;
        }
    }

    printf("System is in a safe state.\nSafe sequence is: ");
    for (int i = 0; i < P; i++) {
        printf("%d ", safeSequence[i]);
    }
    printf("\n");
    return true;
}


bool requestGranted(int processId, int request[R], int available[], int max[P][R], int allocation[P][R]) {
    int need[P][R];
    calculateNeed(need, max, allocation);

    for (int i = 0; i < R; i++) {
        if (request[i] > need[processId][i]) {
            printf("Request exceeds the process's maximum claim.\n");
            return false;
        }
    }

    for (int i = 0; i < R; i++) {
        if (request[i] > available[i]) {
            printf("Resources are not available right now.\n");
            return false;
        }
    }

    for (int i = 0; i < R; i++) {
        available[i] -= request[i];
        allocation[processId][i] += request[i];
        need[processId][i] -= request[i];
    }

    bool safe = isSafe((int[]){0, 1, 2, 3, 4}, available, max, allocation);

    for (int i = 0; i < R; i++) {
        available[i] += request[i];
        allocation[processId][i] -= request[i];
        need[processId][i] += request[i];
    }

    return safe;
}

int main() {

    int processes[] = {0, 1, 2, 3, 4};

    int available[R];
    int max[P][R];
    int allocation[P][R];
    int need[P][R];
    
    printf("Enter available\n");
    for(int i=0;i<R;i++)
    {
    	scanf("%d",&available[i]);
    }
    
    printf("Enter max\n");
    for(int i=0;i<P;i++)
    {
    	for(int j=0;j<R;j++)
    	{
    		scanf("%d",&max[i][j]);
    	}
    }
    
    printf("Enter Allocation\n");
    for(int i=0;i<P;i++)
    {
    	for(int j=0;j<R;j++)
    	{
    		scanf("%d",&allocation[i][j]);
    	}
    }
    
    calculateNeed(need, max, allocation);
    
    printf("The Need matrix is:\n");
    for (int i = 0; i < P; i++) {
        for (int j = 0; j < R; j++) {
            printf("%d ", need[i][j]);
        }
        printf("\n");
    }

    isSafe(processes, available, max, allocation);

    int request[R] = {0, 4, 2, 0};
    if (requestGranted(0, request, available, max, allocation)) {
        printf("Request from P0 (0, 4, 2, 0) can be granted.\n");
    } else {
        printf("Request from P0 (0, 4, 2, 0) cannot be granted.\n");
    }

    return 0;
}

