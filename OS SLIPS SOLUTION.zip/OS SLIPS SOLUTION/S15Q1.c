//LAB A1SA3 //Rohit 1127

#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>
int main()
{
pid_t pid;
pid=fork();

if(pid<0)
{
printf("Failed\n");
return 0;
}
else if (pid==0)
{
printf("This is child\n");
execl("/bin/ls","ls",NULL);
printf("Vishy sampla");
return 1;
}
else
{
sleep(1);
printf("This is parent\n");
}
printf("parent process wake up\n");
wait(NULL);
return 0;
}
