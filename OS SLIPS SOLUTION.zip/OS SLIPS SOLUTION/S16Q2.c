//LAB A4SB1 //Rohit 1127

#include <stdio.h>

int isPageInMemory(int page, int memory[], int frames) {
    for (int i = 0; i < frames; i++) {
        if (memory[i] == page) {
            return 1; // Page found in memory
        }
    }
    return 0; // Page not found in memory
}

void printMemoryState(int memory[], int frames) {
    for (int i = 0; i < frames; i++) {
        if (memory[i] == -1) {
            printf(" - ");
        } else {
            printf(" %d ", memory[i]);
        }
    }
    printf("\n");
}

int main() {
    int frames = 3;  // Fixed number of memory frames
    int referenceString[] = {12, 15, 12, 18, 6, 8, 11, 12, 19, 12, 6, 8, 12, 15, 19, 8}; // Given reference string
    int refSize = sizeof(referenceString) / sizeof(referenceString[0]);

    int memory[frames];
    int pageFaults = 0;
    int index = 0;  // FIFO index to replace oldest page

    // Initialize memory frames to -1 (indicating empty)
    for (int i = 0; i < frames; i++) {
        memory[i] = -1;
    }

    printf("Reference String: ");
    for (int i = 0; i < refSize; i++) {
        printf("%d ", referenceString[i]);
    }
    printf("\n");

    // Simulate FIFO page replacement
    printf("\nPage Scheduling:\n");
    for (int i = 0; i < refSize; i++) {
        int currentPage = referenceString[i];

        // Check if the current page is already in memory
        if (!isPageInMemory(currentPage, memory, frames)) {
            // Page fault occurred, replace page using FIFO
            memory[index] = currentPage;
            index = (index + 1) % frames; // Move to the next frame in circular fashion
            pageFaults++;

            // Print the current memory state
            printMemoryState(memory, frames);
        } else {
            // No page fault, just print the current memory state
            printMemoryState(memory, frames);
        }
    }

    // Output the total number of page faults
    printf("\nTotal number of page faults: %d\n", pageFaults);

    return 0;
}
#include <stdio.h>

int isPageInMemory(int page, int memory[], int frames) {
    for (int i = 0; i < frames; i++) {
        if (memory[i] == page) {
            return 1; // Page found in memory
        }
    }
    return 0; // Page not found in memory
}

void printMemoryState(int memory[], int frames) {
    for (int i = 0; i < frames; i++) {
        if (memory[i] == -1) {
            printf(" - ");
        } else {
            printf(" %d ", memory[i]);
        }
    }
    printf("\n");
}

int main() {
    int frames = 3;  // Fixed number of memory frames
    int referenceString[] = {12, 15, 12, 18, 6, 8, 11, 12, 19, 12, 6, 8, 12, 15, 19, 8}; // Given reference string
    int refSize = sizeof(referenceString) / sizeof(referenceString[0]);

    int memory[frames];
    int pageFaults = 0;
    int index = 0;  // FIFO index to replace oldest page

    // Initialize memory frames to -1 (indicating empty)
    for (int i = 0; i < frames; i++) {
        memory[i] = -1;
    }

    printf("Reference String: ");
    for (int i = 0; i < refSize; i++) {
        printf("%d ", referenceString[i]);
    }
    printf("\n");

    // Simulate FIFO page replacement
    printf("\nPage Scheduling:\n");
    for (int i = 0; i < refSize; i++) {
        int currentPage = referenceString[i];

        // Check if the current page is already in memory
        if (!isPageInMemory(currentPage, memory, frames)) {
            // Page fault occurred, replace page using FIFO
            memory[index] = currentPage;
            index = (index + 1) % frames; // Move to the next frame in circular fashion
            pageFaults++;

            // Print the current memory state
            printMemoryState(memory, frames);
        } else {
            // No page fault, just print the current memory state
            printMemoryState(memory, frames);
        }
    }

    // Output the total number of page faults
    printf("\nTotal number of page faults: %d\n", pageFaults);

    return 0;
}

