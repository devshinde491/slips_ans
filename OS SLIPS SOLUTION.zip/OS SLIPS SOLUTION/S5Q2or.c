//LAB A3SB1 //Rohit 1127

#include <stdio.h>

#define MAX_PROCESSES 10
#define MAX_RESOURCES 10

int available[MAX_RESOURCES];
int allocation[MAX_PROCESSES][MAX_RESOURCES];
int maximum[MAX_PROCESSES][MAX_RESOURCES];
int need[MAX_PROCESSES][MAX_RESOURCES];
int numProcesses, numResources;


void acceptAvailable() {
    printf("Enter number of resources: ");
    scanf("%d", &numResources);
    
    printf("Enter available resources for each resource type:\n");
    for (int i = 0; i < numResources; i++) {
        printf("Resource %d: ", i);
        scanf("%d", &available[i]);
    }
    printf("Available resources accepted.\n");
}


void displayAllocationMax() {
    printf("Enter number of processes: ");
    scanf("%d", &numProcesses);
    
    printf("Enter allocation matrix:\n");
    for (int i = 0; i < numProcesses; i++) {
        for (int j = 0; j < numResources; j++) {
            printf("Allocation for Process %d, Resource %d: ", i, j);
            scanf("%d", &allocation[i][j]);
        }
    }
    
    printf("Enter maximum matrix:\n");
    for (int i = 0; i < numProcesses; i++) {
        for (int j = 0; j < numResources; j++) {
            printf("Maximum for Process %d, Resource %d: ", i, j);
            scanf("%d", &maximum[i][j]);
        }
    }
    
    printf("Allocation matrix:\n");
    for (int i = 0; i < numProcesses; i++) {
        for (int j = 0; j < numResources; j++) {
            printf("%d ", allocation[i][j]);
        }
        printf("\n");
    }
    
    printf("Maximum matrix:");
    for (int i = 0; i < numProcesses; i++) {
        for (int j = 0; j < numResources; j++) {
            printf("%d ", maximum[i][j]);
        }
        printf("\n");
    }
}


void findNeed() {
    for (int i = 0; i < numProcesses; i++) {
        for (int j = 0; j < numResources; j++) {
            need[i][j] = maximum[i][j] - allocation[i][j];
        }
    }
    
    printf("Need matrix:\n");
    for (int i = 0; i < numProcesses; i++) {
        for (int j = 0; j < numResources; j++) {
            printf("%d ", need[i][j]);
        }
        printf("\n");
    }
}


void displayAvailable() {
    printf("Available resources:\n");
    for (int i = 0; i < numResources; i++) {
        printf("%d ", available[i]);
    }
    printf("\n");
}


void menu() {
    int choice;
    while (1) {
        printf("\nBanker's Algorithm Menu:\n");
        printf("1. Accept Available Resources\n");
        printf("2. Display Allocation and Maximum Matrices\n");
        printf("3. Find and Display Need Matrix\n");
        printf("4. Display Available Resources\n");
        printf("5. Exit\n");

        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                acceptAvailable();
                break;
            case 2:
                displayAllocationMax();
                break;
            case 3:
                findNeed();
                break;
            case 4:
                displayAvailable();
                break;
            case 5:
                return;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    }
}

int main() {
    menu();
    return 0;
}

