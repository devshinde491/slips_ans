//LAB A3SB2 //Rohit 1127

#include<stdio.h>
int main()
{
    int allocation[5][3]={{0,1,0},
                          {2,0,0},
                          {3,0,3},
                          {2,1,2},
                          {0,0,2}
                         };
    int request[5][3]={{0,0,0},
                       {2,0,2},
                       {0,0,1},
                       {1,0,0},
                       {0,0,2}
                      };
    int available[3],total_resources[3]={7,2,6};
    int allocated_sum[3]={0,0,0};
    for(int i=0;i<5;i++)
    {
        for(int j=0;j<3;j++)
        {
            allocated_sum[j]+=allocation[i][j];
        }
    }
    for(int i=0;i<3;i++)
    {
        available[i]=total_resources[i]-allocated_sum[i];
    }
    printf("Available resources: A=%d,B=%d,C=%d \n",available[0],available[1],available[2]);
    int finish[5]={0,0,0,0,0};
    int deadlock=0;
    for(int k=0;k<5;k++)
    {
        for(int i=0;i<5;i++)
        {
            if(!finish[i])
            {
                int can_finish=1;
                for(int j=0;j<3;j++)
                {
                    if(request[i][j]>available[j])
                    {
                        can_finish=0;
                        break;
                    }
                }
                if(can_finish)
                {
                    for(int j=0;j<3;j++)
                    {
                        available[j]+=allocation[i][j];
                    }
                    finish[i]=1;
                }
            }
        }
    }
    for(int i=0;i<5;i++)
    {
        if(!finish[i])
        {
            deadlock=1;
            break;
        }
    }
    if(deadlock)
    {
        printf("Deadlock detected.\n");
    }
    else
    {
    printf("No Deadlock.All process an finish.\n");
    }
return 0;
}
                      
