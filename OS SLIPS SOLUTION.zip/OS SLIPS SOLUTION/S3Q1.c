//LAB A1SA2 //Rohit 1127

#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<stdlib.h>
int main()
{
char *command="ls";
char *argument_list[]={"ls","-1",NULL};
printf("Before calling execvp()");
int status_code=execvp(command,argument_list);
if(status_code==-1)
{
printf("process did not terminate correctly");
exit(1);
}
printf("this line will not be printed if execup() runs correctly");
return 0;
}
