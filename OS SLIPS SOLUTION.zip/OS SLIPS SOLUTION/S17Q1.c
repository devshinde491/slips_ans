//LAB A3SA1 //Rohit 1127

#include <stdio.h>
#include <stdbool.h>
#define MAX 10

void calculate_min_resources(int n, int m, int max_resources[], int allocated_resources[][MAX], int requested_resources[][MAX]);
bool is_safe_state(int n, int m, int available_resources[], int allocated_resources[][MAX], int requested_resources[][MAX]);

int main() {
    int n, m;
    printf("Enter the number of processes: ");
    scanf("%d", &n);
    printf("Enter the number of resource types: ");
    scanf("%d", &m);
    
    int max_resources[m];
    int allocated_resources[MAX][MAX];
    int requested_resources[MAX][MAX];
    
    printf("Enter the maximum number of resources for each type:\n");
    for (int i = 0; i < m; i++) {
        printf("Resource %d: ", i);
        scanf("%d", &max_resources[i]);
    }
    
    printf("Enter the allocated resources for each process:\n");
    for (int i = 0; i < n; i++) {
        printf("Process %d:\n", i);
        for (int j = 0; j < m; j++) {
            printf("Resource %d: ", j);
            scanf("%d", &allocated_resources[i][j]);
        }
    }
    
    printf("Enter the requested resources for each process:\n");
    for (int i = 0; i < n; i++) {
        printf("Process %d:\n", i);
        for (int j = 0; j < m; j++) {
            printf("Resource %d: ", j);
            scanf("%d", &requested_resources[i][j]);
        }
    }
    
    calculate_min_resources(n, m, max_resources, allocated_resources, requested_resources);
    
    return 0;
}

void calculate_min_resources(int n, int m, int max_resources[], int allocated_resources[][MAX], int requested_resources[][MAX]) {
    int min_resources[m];
    for (int i = 0; i < m; i++) {
        min_resources[i] = 0;
        for (int j = 0; j < n; j++) {
            min_resources[i] = (min_resources[i] > requested_resources[j][i] - allocated_resources[j][i]) ?
                               min_resources[i] : requested_resources[j][i] - allocated_resources[j][i];
        }
        if (min_resources[i] < 0) {
            min_resources[i] = 0;
        }
    }
    
    printf("Minimum resources needed to avoid deadlock:\n");
    for (int i = 0; i < m; i++) {
        printf("Resource %d: %d\n", i, min_resources[i] + max_resources[i]);
    }
}

bool is_safe_state(int n, int m, int available_resources[], int allocated_resources[][MAX], int requested_resources[][MAX]) {
    int work[m];
    bool finish[n];
    for (int i = 0; i < m; i++) {
        work[i] = available_resources[i];
    }
    for (int i = 0; i < n; i++) {
        finish[i] = false;
    }
    
    int count = 0;
    while (count < n) {
        bool progress = false;
        for (int i = 0; i < n; i++) {
            if (!finish[i]) {
                bool can_satisfy = true;
                for (int j = 0; j < m; j++) {
                    if (requested_resources[i][j] > work[j]) {
                        can_satisfy = false;
                        break;
                    }
                }
                if (can_satisfy) {
                    for (int k = 0; k < m; k++) {
                        work[k] += allocated_resources[i][k];
                    }
                    finish[i] = true;
                    progress = true;
                    count++;
                }
            }
        }
        if (!progress) {
            return false;
        }
    }
    return true;
}



