//LAB A4SA1 //Rohit 1127

#include <stdio.h>

int isPageInMemory(int page, int memory[], int frames) {
    for (int i = 0; i < frames; i++) {
        if (memory[i] == page) {
            return 1; // Page is found in memory
        }
    }
    return 0; // Page not found in memory
}

void printMemoryState(int memory[], int frames) {
    for (int i = 0; i < frames; i++) {
        if (memory[i] == -1) {
            printf(" - ");
        } else {
            printf(" %d ", memory[i]);
        }
    }
    printf("\n");
}

int main() {
    int n;  // Number of memory frames
    int referenceString[] = {0, 2, 1, 6, 4, 0, 1, 0, 3, 1, 2, 1}; // Given reference string
    int refSize = sizeof(referenceString) / sizeof(referenceString[0]);

    printf("Enter the number of memory frames: ");
    scanf("%d", &n);

    int memory[n];
    int pageFaults = 0;
    int index = 0;  // FIFO index to replace the oldest page

    // Initialize memory frames to -1 (indicating empty)
    for (int i = 0; i < n; i++) {
        memory[i] = -1;
    }

    printf("Reference String: ");
    for (int i = 0; i < refSize; i++) {
        printf("%d ", referenceString[i]);
    }
    printf("\n");

    // Simulate FIFO page replacement
    printf("\nPage Scheduling:\n");
    for (int i = 0; i < refSize; i++) {
        int currentPage = referenceString[i];

        // Check if the current page is already in memory
        if (!isPageInMemory(currentPage, memory, n)) {
            // Page fault occurred, replace page using FIFO
            memory[index] = currentPage;
            index = (index + 1) % n; // Move to the next frame in circular fashion
            pageFaults++;

            // Print the current memory state
            printMemoryState(memory, n);
        } else {
            // No page fault, just print the current memory state
            printMemoryState(memory, n);
        }
    }

    // Output the total number of page faults
    printf("\nTotal number of page faults: %d\n", pageFaults);

    return 0;
}

