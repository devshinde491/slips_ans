//LAB A1SA1 //Rohit 1127

#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
int main()
{
int pid;
pid=fork();
if(pid<0)
{
printf("\n Error in creation of child process");
exit(1);
}
else if(pid==0)
{
printf("\n Hello i am the child process");
printf(" \n My pid is %d ",getpid());
printf("\n Hello world\n");
exit(0);
}
else
{
printf("\n Hello i am the parent process");
printf("\n My pid is %d ",getpid());
printf("\n Hi\n");
exit(1);
}
}
