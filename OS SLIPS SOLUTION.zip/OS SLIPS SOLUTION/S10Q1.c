//LAB A1SB1 //Rohit 1127

#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<stdlib.h>
int main()
{
pid_t pid;
pid=fork();
if(pid<0)
{
perror("Fork faild");
return 1;
}
else if(pid==0)
{

printf("child process(PID:%d) parent (PID:%d)\n",getpid(),getppid());
sleep(10);
printf("parent process(PID:%d) after termination, new parent (PID:%d)\n",getpid(),getppid());
}
else
{
printf("Parent process(PID:%d)\n",getpid());
sleep(3);
printf("parent process(PID:%d)terminating\n",getpid());
}
return 0;
}
