import numpy as np
from sklearn import linear_model 
x=np.array([[0],[1],[2],[3],[4],[5],[6],[7],[8],[9],[11],[13]])
y=np.array([1,3,2,5,7,8,8,9,10,12,16,18])
print(x)
print(y)
model=linear_model.LinearRegression()
model.fit(x,y)
r_sq=model.score(x,y)
print('coeficient pf determination',r_sq)
print('intercept :',model.intercept_)
print('slope :',model.coef_)

