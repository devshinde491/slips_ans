from sklearn import linear_model
import numpy as np
import matplotlib.pyplot as plt 
def estimate(x,y):
    a=np.size(x)
model=linear_model.LinearRegression()

mean
sum_x = np.sum(x)
sum_y = np.sum(y)
sum_xy = np.sum(x * y)
sum_x_squared = np.sum(x ** 2)
b1 = sum_xy / sum_x_squared
b0 = sum_y - b1 * sum_x


def plot_reg(x,y,b):
    plt.scatter(x,y,color='red',marker='*')
    y_predicted=b[0]+b[1]
    plt.plot(x,y_predicted,color='green')
    plt.xlabel('size')
    plt.ylabel('cost')
    plt.show()
    x = np.array([0,1,2,3,4,5,6,7,8,9,11,13])
    y = np.array([1,3,2,5,7,8,9,10,12,16,18])
    b =  estimate(x,y)
    
    