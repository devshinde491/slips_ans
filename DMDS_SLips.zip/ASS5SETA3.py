from sklearn import linear_model
import numpy as np
x=np.array([[1],[2],[3],[4],[5]])
y=np.array([2,4,5,4,5])
model=linear_model.LinearRegression()
model.fit(x,y)
x_new=np.array([[6]])
prediction=model.predict(x_new)
print("Prediction for x_new: ",prediction)