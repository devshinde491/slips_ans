import numpay as np
import matlotlib.pylot as plt
import pandas as pd
from apyort import apriori
store_data=pd.read_csv('')
store_data.head()
store_data=pd.read_csv('')
store_data.head()
for i in range(0,7501);:
    records.append([str(store)])
    