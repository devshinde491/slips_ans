from sklearn import linear_model
import numpy as np
x = np.array([[0],[1],[2],[3],[4],[5],[6],[7],[8],[9],[11],[13]])
y = np.array([1,3,2,5,7,8,8,9,10,12,16,18])
model=linear_model.LinearRegression()
model.fit(x,y)
n = len(x)
sum_x = np.sum(x)
sum_y = np.sum(y)
sum_xy = np.sum(x * y)
sum_x_squared = np.sum(x ** 2)
b1 = sum_xy / sum_x_squared
b0 = sum_y - b1 * sum_x
return b0,b1

def plot_reg(x,y,b):
    ptl.scatter()
    print("b0 (Intercept):",model.intercept_)
print("b1 (Slope):",model.coef_)