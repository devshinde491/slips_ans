#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Oct  4 09:21:59 2024

@author: mitacsc
"""

import pandas as  pd
import numpy as np

df=pd.read_csv('/home/mitacsc/Desktop/TE 3329/dmds/studentperformance.csv')

print("shape of the dataset:",df.shape)
print("\n top rows of the dataset:")
print(df.head())
 
print("\n random rows from datasets:")
print(df.sample(5))

print("\n number of Columns:",len(df.columns))
print("names of the Columns:")
print(df.columns)


