import pandas as pd
from sklearn import tree
from sklearn.tree import DecisionTreeClassifier

dataset=pd.read_csv("/home/bcalab-30/TE3330/R/decison tree.csv")
d={'UK':0,'USA':1,'N':2}
dataset['Nationality']=dataset['Nationality'].map(d)
d={'YES':1,'NO':0}
dataset['Go']=dataset['Go'].map(d)
x=dataset.iloc[:,:-1].values
y=dataset.iloc[:,4].values
dtree=DecisionTreeClassifier()
dtree=dtree.fit(x,y)
print(dtree.predict([[40,10,7,1]]))