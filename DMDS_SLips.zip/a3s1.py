import numpy as np
import pandas as pd

dataset=pd.read_csv('/home/bcalab-30/Downloads/PlayTennis.csv')

from sklearn.preprocessing import LabelEncoder

Le = LabelEncoder()

dataset['Outlook'] =Le.fit_transform(dataset['Outlook'])
dataset['Temperature'] =Le.fit_transform(dataset['Temperature'])
dataset['Humidity'] =Le.fit_transform(dataset['Humidity'])
dataset['Wind'] =Le.fit_transform(dataset['Wind'])
dataset['Play Tennis'] =Le.fit_transform(dataset['Play Tennis'])

X = dataset.iloc[:,:-1].values
y = dataset.iloc[:,:4].values

from sklearn import tree
clf = tree.DecisionTreeClassifier(criterion='entropy')
clf = clf.fit(X,y)

tree.plot_tree(clf)

X_pred =clf.predict(X)

X_pred == y