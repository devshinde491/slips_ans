import numpy as np
import pandas as pd
dataset=pd.read_csv('/home/bcalab-30/TE3330/R/PlayTennis.csv')

