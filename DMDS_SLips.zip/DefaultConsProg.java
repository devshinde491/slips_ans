class DefaultConsProg

