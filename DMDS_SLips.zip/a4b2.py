import pandas as pd


df = pd.read_csv('/home/bcalab-30/TE3330/Dmds/iris.csv')
print(df.head())

df = df.astype(str)

transactions = df.values.tolist()

min_support = 0.1
min_confidence = 0.5
min_lift = 2
min_length = 2


rules = apriori(transactions, min_support=min_support, min_confidence=min_confidence, min_lift=min_lift, min_length=min_length)


results = list(rules)

def inspect(rules_list):
    rules_summary = []
    for rule in rules_list:
        
        base_items = list(rule.ordered_statistics[0].items_base)
        add_items = list(rule.ordered_statistics[0].items_add)
        

        rules_summary.append({
            "Base": base_items,
            "Add": add_items,
            "Support": rule.support,
            "Confidence": rule.ordered_statistics[0].confidence,
            "Lift": rule.ordered_statistics[0].lift
        })
    return pd.DataFrame(rules_summary)


rules_df = inspect(results)


print(rules_df.head())