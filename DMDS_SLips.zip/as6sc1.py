from sklearn import datasets
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import AgglomerativeClustering
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

iris = datasets.load_iris()
X = iris.data
data = pd.DataFrame(X, columns=iris.feature_names)

cor = data.corr()

sns.heatmap(cor, square=True)
plt.show()

scaler = StandardScaler()
X_std = scaler.fit_transform(X)

clt = AgglomerativeClustering(linkage="complete", affinity="euclidean")
model = clt.fit(X_std)

clusters = pd.DataFrame(model.fit_predict(X_std), columns=['Cluster'])
data["Cluster"] = clusters


fig = plt.figure()
ax = fig.add_subplot(111)
scatter = ax.scatter(data.iloc[:, 0], data.iloc[:, 1], c=data["Cluster"], s=50)
ax.set_title("Agglomerative Clustering")
ax.set_xlabel(iris.feature_names[0])
ax.set_ylabel(iris.feature_names[1])
plt.colorbar(scatter)
plt.show()
