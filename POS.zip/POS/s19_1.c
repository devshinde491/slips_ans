// Write a program to create a child process using fork().The parent should goto sleep state and child process should begin its execution. In the child process, use execl() to execute the “ls” command.

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main()
{
    int pid = fork();

    if (pid < 0)
    {
        printf("Failed to create process.\n");
        return 1;
    }
    else if (pid == 0)
    {
        printf("Child Process ");
        execl("/bin/ls", "ls", NULL);
    }
    else
    {
        printf("Parent Process ");
        sleep(5);
    }

    return 0;
}
