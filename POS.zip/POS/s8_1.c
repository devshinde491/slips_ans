// Write a C program to accept the number of process and resources and find the need matrix content and display it
