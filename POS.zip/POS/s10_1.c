// Write a program to illustrate the concept of orphan process (Using fork() and sleep())
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main()
{
    int pid = fork(); 

    if (pid < 0) 
    {
        printf("Failed to create process.\n");
        return 1;
    }
    else if (pid == 0) 
    {
        sleep(10); 
        printf("Child process finished.\n");
    }
    else 
    {
        printf("Parent process finished.\n");
    }

    return 0;
}
