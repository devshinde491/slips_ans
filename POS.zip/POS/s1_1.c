// Write a program that demonstrates the use of nice() system call. After a child process is started using fork(), assign higher priority to the child using nice() system call.
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main()
{
    int pid = fork(); 
    int retnice;
    for(int i =0;i<2;i++){
        if (pid < 0) 
        {
            printf("Failed to create process.\n");
            return 1;
        }
        else if (pid == 0) 
        {
            retnice = nice(-5);
            printf("Child having higher priority which is : %d.\n", retnice);
        }
        else 
        {
            retnice = nice(5);
            printf("Parent having less priority which is : %d.\n", retnice);
        }
    }
    return 0;
}
