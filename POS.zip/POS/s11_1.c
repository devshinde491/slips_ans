//  Create a child process using fork(), display parent and child process id. Child process willdisplay the message “Hello World” and the parent process should display “Hi”.
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main()
{
    int pid = fork(); 

    if (pid < 0) 
    {
        printf("Failed to create process.\n");
        return 1;
    }
    else if (pid == 0) 
    {
        printf("Child Process Id : %d\n",getpid());
        printf("Hello World\n");
    }
    else 
    {
        printf("Parent Process Id : %d\n",getppid());
        printf("Hii.\n");
    }

    return 0;
}
