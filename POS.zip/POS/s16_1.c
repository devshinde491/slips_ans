//  Write a program to find the execution time taken for execution of a given set of instructions (use clock() function)
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
int main()
{
    clock_t start = clock();
    int pid = fork();
    clock_t end = clock();
    double time_taken = ((double)(end - start)) / CLOCKS_PER_SEC;
    if (pid < 0)
    {
        printf("Failed to create process.\n");
        return 1;
    }
    else if (pid == 0)
    {
        printf("Child Process Id : %d\n", getpid());
        printf("Child process taken time is : %f ", time_taken);
    }
    else
    {
        printf("Parent Process Id : %d\n", getppid());
    }

    return 0;
}
