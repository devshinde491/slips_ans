#include<stdio.h>
int nop,nor,A[10][10],M[10][10],Av[10],N[10][10],finish[10][10];

void acceptdata(int x[10][10])
{
	int i,j;
	for(i=0;i<nop;i++)
	{
		printf("P%d\n",i);
		for(j=0;j<nor;j++)
		{
			printf("%c: ",65+j);
			scanf("%d",&x[i][j]);
		}
	}
}

void acceptav()
{
	int i;
	for(i=0;i<nor;i++)
	{
		printf("%c: ",65+i);
		scanf("%d",&Av[i]);
	}
}

void calcneed()
{
	int i,j;
	for(i=0;i<nop;i++)
	{
		for(j=0;j<nor;j++)
		{
			N[i][j]=M[i][j]-A[i][j];
		}
	}
}

void displayAM()
{
	int i,j;
	printf("\n\t\tAllocation \tMax\n\t");
	for(j=0;j<2;j++)
	{
		for(i=0;i<nor;i++)
		{
			printf("%4c",65+i);
		}
	}
	for(i=0;i<nop;i++)
	{
		printf("\nP%d\t",i);
		for(j=0;j<nor;j++)
		{
			printf("%4d",A[i][j]);
		}
		for(j=0;j<nor;j++)
		{
			printf("%4d",M[i][j]);
		}
	}
}

void displayNeed()
{
	int i,j;
	printf("\n\t\tNeed\n\t");
	for(i=0;i<nor;i++)
	{
		printf("%4c",65+i);
	}
	for(i=0;i<nop;i++)
	{
		printf("\nP%d\t",i);
		for(j=0;j<nor;j++)
		{
			printf("%4d",N[i][j]);
		}
	}
}

void displayAv()
{
	int i;
	printf("\nAvailable: \n");
	for(i=0;i<nor;i++)
	{
		printf("%4c",65+i);
	}
	printf("\n");
	for(i=0;i<nor;i++)
	{
		printf("%4d",Av[i]);
	}
}

int main()
{
	int a;
	printf("\nEnter Number of Processes: ");
	scanf("%d",&nop);
	printf("\nEnter Number of Resources: ");
	scanf("%d",&nor);
	printf("Enter Allocation Matrix: \n");
	acceptdata(A);
	printf("\nEnter Max Matrix: \n");
	acceptdata(M);
	do
	{
		printf("\n1.Accept Available.\n2.Display Allocation,Max\n3.Find Need and Display it\n4.Display Available.\nENTER 0 FOR EXIT.");
		printf("Enter your choice:	");
		scanf("%d",&a);
		switch(a)
		{
			case 1:
				printf("\nEnter Availability: \n");
				acceptav();
				break;
			case 2:
				displayAM();
				break;
			case 3:
				calcneed();
				displayNeed();
				break;
			case 4:
				displayAv();
				break;
			default:
				printf("Invalid Input!!");
				break;
		}
	}while(a>0);
}
