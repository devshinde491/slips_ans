#include<stdio.h>
int nor,nof,refstring[30],f[10];
void accept()
{
	int i;
	printf("enter the reference String:\n");
	for(i=0;i<nor;i++)
	{
	printf("[%d]:",i);
	scanf("%d",&refstring[i]);
	}
}
int search(int page)
{
	int i;
	for(i=0;i<nof;i++)
	{
	if(page==f[i])
	return i;
	}
	return -1;
}
void FIFO()
{
	int i,j,k,fno=0,fault=0;
	for(i=0;i<nor;i++)
	{
	printf("\n %d",refstring[i]);
	k=search(refstring[i]);
	if(k==-1)
	{
	f[fno]=refstring[i];
	for(j=0;j<nof;j++)
	{
	if(f[j])
	printf("\t%d",f[j]);
	}
	fault ++;
	fno=(fno+1)%nof;
	}
	}
	printf("\n total no.of page fault:%d",fault);
}
	int main()
	{
	printf("\n enter the length of string:");
	scanf("%d",&nor);
	printf("\n enter no of frames:");
	scanf("%d",&nof);
	accept();
	FIFO();
}
		
		
