 #include<stdio.h>
 #include<string.h>
struct input
{
  char pname[10];
  int bt,at,tbt,ft;
}tab[10];
struct gantt
{
  int start,end;
  char pname[10];
}g[50],g1[10];
int n,i,k,time,prev;
void getinput()
{
  printf("\nEnter No of Processes: ");
  scanf("%d",&n);
  for(i=0;i<n;i++)
  {
    printf("\nProcess Name: ");
    scanf("%s",tab[i].pname);
    printf("Burst Time: ");
    scanf("%d",&tab[i].bt);
    tab[i].tbt=tab[i].bt;
    printf("Arrival Time:" );
    scanf("%d",&tab[i].at);
  }
}
void printinput()
{
  printf("\nPname\tBT\tAT");
  for(i=0;i<n;i++)
    printf("\n%s\t%d\t%d",tab[i].pname,tab[i].tbt,tab[i].at);

}
void sort()
{
  struct input temp;
  int j;
   for(i=1;i<n;i++)//pass
    for(j=0;j<n-1;j++)//Comp
       if(tab[j].at>tab[j+1].at)
       {
          temp=tab[j];
          tab[j]=tab[j+1];
          tab[j+1]=temp;
       }
}
int arrived(int time)
{
   for(i=0;i<n;i++)  
   if(tab[i].at<=time && tab[i].tbt!=0)
        return 1;
     return 0;
}
void processinput()
{
	int j,finish=0;
//	time=tab[0].at;
    while(finish!=n)
	{
		if(arrived(time))
		{
                   	for(j=0;j<tab[i].bt;j++)
			{
				time++;
				tab[i].tbt--;
			        g[k].start=prev;
				g[k].end=time;
		//		printinput();
 				prev=time;
				tab[i].ft=time;
				strcpy(g[k++].pname,tab[i].pname);
                                if(tab[i].tbt==0)
                                { 
  				 finish++;
				 break;
 				}
                   	}
		}
 		else
  		{
 	                  time++;
			  g[k].start=prev;
			  g[k].end=time;
			  prev=time;
			  strcpy(g[k++].pname,"idle");
		}
 
	}

    // printinput();
}  
void printoutput()
{
   int TTAT=0,TWT=0;
 float ATAT,AWT;
   printf("\n******Final Table*****");
   printf("\nPname\tAT\tBT\tFT\tTAT\tWT");
   for(i=0;i<n;i++)
   {
 printf("\n%s\t%d\t%d\t%d\t%d\t%d",tab[i].pname,tab[i].at,tab[i].bt,tab[i].ft,tab[i].ft-tab[i].at,tab[i].ft-tab[i].at-tab[i].bt);
       TTAT=TTAT+(tab[i].ft-tab[i].at);
       TWT=TWT+(tab[i].ft-tab[i].at-tab[i].bt);
   }
  ATAT=(float)TTAT/n;
  AWT=(float)TWT/n;
 printf("\nTotal TAT=%d",TTAT);
 printf("\nTotal WT=%d",TWT);
 printf("\nAverage TAT=%f",ATAT);
 printf("\nAverage WT=%f",AWT);
 
}
void printganttchart()
{
  int j=0;
   g1[0]=g[0];    
   for(i=1;i<k;i++)
    {
        if(strcmp(g1[j].pname,g[i].pname)==0)
	   g1[j].end=g[i].end;
         else
	{
		j++;
  	        g1[j]=g[i];
        }
    }		
  printf("\n******Each unit Gantt chart******");

       for(i=0;i<k;i++)
        printf("\n%d\t%s\t%d",g[i].start,g[i].pname,g[i].end);

 printf("\n******Final Gantt chart******");
       for(i=0;i<=j;i++)
         printf("\n%d\t%s\t%d",g1[i].start,g1[i].pname,g1[i].end);

    
}
int main()
{
  getinput();
  printf("\nEntered data is: ");
  printinput();
  sort();
  printf("\nData after Sorting" );
  printinput();
  processinput();
  printoutput();
  printganttchart();
}
