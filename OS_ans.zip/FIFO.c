#include<stdio.h>
int refstring[30],nor,nof,F[10];
void accept()
{
	int i;
	printf("\nEnter reference String:\n"); //accepting th reference string
	for(i=0;i<nor;i++)
	{
		printf("[%d]: ",i);
		scanf("%d",&refstring[i]);
	}
}

int search(int page)      // searching if the page recides in the frames
{
	int i;
	for(i=0;i<nof;i++)
	{
		if(page==F[i]) // if page is in the frames then return i
			return i;
	}
	return -1;// if page is not in the frames return -1
}

void FIFO()
{
	int i,j,k,fno=0,fault=0;
	for(i=0;i<nor;i++)
	{
		printf("\n%d",refstring[i]);  //prints the reference string on the left side
		k=search(refstring[i]); //searching for the page or current reference string in frames
		if(k==-1)	//if the page is not present in frames
		{
			F[fno]=refstring[i];// add it to the frames
			for(j=0;j<nof;j++)
			{
				if(F[j])
					printf("\t%d",F[j]);		//if frame has a pagevalue then print it
			}
			fault++;			//if page is added to the frame increase the page fault by 1
			fno=(fno+1)%nof; //iterate the frameno so that it won't exceed the limit of nof
		}
	}
	printf("\nTotal no of page fault:%d.\n",fault);//printing the total page fault
}

int main()
{
	printf("\nEnter the length of string: \n");
	scanf("%d",&nor);
	printf("\nEnter number of frames: \n");
	scanf("%d",&nof);
	accept();
	FIFO();
}


/*
Enter the length of string: 
12

Enter number of frames: 
3

Enter reference String:
[0]: 10
[1]: 2
[2]: 1
[3]: 6
[4]: 4
[5]: 10
[6]: 1
[7]: 10
[8]: 3
[9]: 1
[10]: 2
[11]: 1

10	10
2	10	2
1	10	2	1
6	6	2	1
4	6	4	1
10	6	4	10
1	1	4	10
10
3	1	3	10
1
2	1	3	2
1
Total no of page fault:9.
*/
